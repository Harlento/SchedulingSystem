<?php
/*  Developer:   Justin Alho, Harley Lenton
 *  File Name:   viewstaff.php
 *  Description: Allows coordinators to view existing staff members and select to modify them
 *  Date Start:  25/02/2020
 *  Date End:    TBD
 *  TODO:    	 - add sorting, filtering
 */?>
<?php
echo'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	        <title>View Staff Information</title>
    <title>Table</title>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/table.css" rel="stylesheet" type="text/css">

</head>
<body>
';
		
			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
		
		 include "../includes/scripts/headLinks2.0.php";
		include "../includes/scripts/navBar.php";


		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);

			//connect to the database
			$username = 'oldcount_edenbridge1';
			$password = 'z}[!IKVm5Ze9';
			$conn = new PDO("mysql:host=localhost; dbname=oldcount_edenbridge", $username, $password);
					
			//retrieve staff information from the database
			$sql = $conn->prepare("SELECT STAFF_ID, C_S_STATUS_NAME, TYPE_NAME, USER_NAME, STAFF_FNAME, STAFF_LNAME, STAFF_PHONE, STAFF_ADDRESS, STAFF_CITY, CAN_CHILD, CAN_PC, CAN_DRIVE, SUN_AVAIL, MON_AVAIL, TUE_AVAIL, WED_AVAIL, THU_AVAIL, FRI_AVAIL, SAT_AVAIL, STAFF_NOTES
			FROM STAFF
			LEFT JOIN C_S_STATUS
			ON STAFF.STAFF_STATUS = C_S_STATUS.C_S_STATUS_CODE
			LEFT JOIN USER_TYPE
			ON STAFF.TYPE_CODE = USER_TYPE.TYPE_CODE
			ORDER BY STAFF_LNAME");
				
			$sql->execute();
			
			$row = $sql->fetchAll();
			

			
			//if there is a successful update from modstaff.php, display a success message
			if(isset($_REQUEST['p']))
				echo "Staff member modified successfully.<br /><br />";
			
			//set up table headers
			echo
			"<table class='table-sm' border='1'>
				<tr>
					<th>Staff</th>
					<th>Status</th>
					<th>Staff Type</th>
					<th>Username</th>
					<th>Phone Number</th>
					<th>Address</th>
					<th>City</th>
					<th>Can Work with Children</th>
					<th>Can Provide Personal Care</th>
					<th>Can Drive</th>
					<th>Sunday Availability:</th>
					<th>Monday Availability:</th>
					<th>Tuesday Availability:</th>
					<th>Wednesday Availability:</th>
					<th>Thursday Availability:</th>
					<th>Friday Availability:</th>
					<th>Saturday Availability:</th>
					<th>Notes</th>
					<th></th>
				</tr>
			";
			
			//include function to convert availability to 12 hour time
			include "../includes/functions/convertHours.php";
			
			//fill table with records from database
			foreach ($row as $data)
			{	
				echo "<tr>";
				echo "<td>{$data['STAFF_LNAME']}, {$data['STAFF_FNAME']}</td>";
				echo "<td>{$data['C_S_STATUS_NAME']}</td>";
				echo "<td>{$data['TYPE_NAME']}</td>";
				echo "<td>{$data['USER_NAME']}</td>";
				echo "<td>{$data['STAFF_PHONE']}</td>";
				echo "<td>{$data['STAFF_ADDRESS']}</td>";
				echo "<td>{$data['STAFF_CITY']}</td>";
				if($data['CAN_CHILD'] == 1)
					echo "<td>Yes</td>";
				else
					echo "<td>No</td>";
				if($data['CAN_PC'] == 1)
					echo "<td>Yes</td>";
				else
					echo "<td>No</td>";
				if($data['CAN_DRIVE'] == 1)
					echo "<td>Yes</td>";
				else
					echo "<td>No</td>";
				
				/////////////////////////////////////////////////////
				/////////////Converting hour format here///////////
				
				$sunAvail = convertTime($data['SUN_AVAIL']);
				$monAvail = convertTime($data['MON_AVAIL']);
				$tueAvail = convertTime($data['TUE_AVAIL']);
				$wedAvail = convertTime($data['WED_AVAIL']);
				$thuAvail = convertTime($data['THU_AVAIL']);
				$friAvail = convertTime($data['FRI_AVAIL']);
				$satAvail = convertTime($data['SAT_AVAIL']);
				
				
				//test values
				//print($sunAvail . "<br />");
				//print($monAvail . "<br />");
				//print($tueAvail . "<br />");
				//print($wedAvail . "<br />");
				//print($thuAvail . "<br />");
				//print($friAvail . "<br />");
				//print($satAvail . "<br />");
				
				//var_dump(function_exists('convert'));
				//test
				//echo "<td>{$data['SUN_AVAIL']}</td>";
				
				echo "<td>" . $sunAvail . "</td>";
				echo "<td>" . $monAvail . "</td>";
				echo "<td>" . $tueAvail . "</td>";
				echo "<td>" . $wedAvail . "</td>";
				echo "<td>" . $thuAvail . "</td>";
				echo "<td>" . $friAvail . "</td>";
				echo "<td>" . $satAvail . "</td>";
				echo "<td>{$data['STAFF_NOTES']}</td>";
				echo "<td><a href='modstaff.php?id={$data['STAFF_ID']}' class='btn btn-info'>modify</a></td>";
				echo "</tr>";
			}
				
			echo "</table><br />\n";
			
			echo "<a href='/staff/' class='btn btn-secondary'>Back</a><br /><br />";
			
			//Releasing database resources
			$conn = null;
			$sql = null;
			include "../includes/scripts/footer.php";
			
echo'
            

    </form>
</form>
</div>';

	echo'
</body>
</html>
    ';
	?>
	