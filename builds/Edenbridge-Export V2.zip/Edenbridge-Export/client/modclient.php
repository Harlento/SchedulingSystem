<?php
/*  Developer:   Justin Alho
 *  File Name:   modclient.php
 *  Description: Allows coordinators to modify existing client records
 *  Date Start:  25/02/2020
 *  Date End:    TBD
 */?>
  <?php
echo'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
                     <title>Modify Client</title>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/table.css" rel="stylesheet" type="text/css">


</head>
<body>';

			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
			
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php"; 

			//level of authorization required to access page
			$authLevel = "C";
		
			//to verify the user
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);

            //connect to the database
            $username = 'oldcount_edenbridge1';
            $password = 'z}[!IKVm5Ze9';
            $conn = new PDO("mysql:host=localhost; dbname=oldcount_edenbridge", $username, $password);
		
			//initialize variables
			$id = '';
			$status = '';
			$gh = '';
			$fname = '';
			$lname = '';
			$phone = '';
			$address = '';
			$city = '';
			$hours = '';
			$km = '';
			$notes = '';
			
			$fnamerr = '';
			$lnamerr = '';
			
			//if the form has been submitted
			if(isset($_POST['submit']))
			{	
				//set error counter to 0
				$err = 0;
				
				//set variables to submitted values
				$id = $_POST['id'];
				$status = $_POST['status'];
				$gh = $_POST['gh'];
				$fname = $_POST['fname'];
				$lname = $_POST['lname'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				$hours = $_POST['hours'];
				$km = $_POST['km'];
				$notes = $_POST['notes'];

				//if required fields are blank, set the corresponding error message and increment error counter
				if($fname == '')
				{
					$fnamerr = 'Please enter a first name.';
					$err++;
				}
				if($lname == '')
				{
					$lnamerr = 'Please enter a last name.';
					$err++;
				}
				
				//if there are no errors, add information into database
				if($err == 0)
				{
					$modsql = $conn->prepare("UPDATE CLIENT SET CLIENT_STATUS = '$status', GH_ID = '$gh', CLIENT_FNAME = '$fname', CLIENT_LNAME = '$lname', CLIENT_PHONE = '$phone', CLIENT_ADDRESS = '$address', CLIENT_CITY = '$city',
					CLIENT_MAX_HOURS = '$km', CLIENT_KM = '$km', CLIENT_NOTES = '$notes'
					WHERE CLIENT_ID = '$id'");
					
					$modsql->execute();
					
					//echo implode(":",$modsql->errorInfo());
					
					//log whenever the database is updated
					date_default_timezone_set("US/Mountain");
					//F j, Y, g:i a
					$dateString = date("r");
					file_put_contents("../logs/clientModLog.txt", "\n" . $fname . " " . $lname . " was modified on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
					
					//send user back to list of clients with a success message
					header('Location: viewclient.php?s=1');
				}
			}
			
			//set ID variable to ID sent by viewclient.php
			$id = $_REQUEST['id'];
			
			//retrieve selected client's information from database
			$sql = $conn->prepare("SELECT CLIENT_ID, CLIENT_STATUS, C_S_STATUS_CODE, C_S_STATUS_NAME, CLIENT.GH_ID, GH_NAME, CLIENT_FNAME, CLIENT_LNAME, CLIENT_PHONE, CLIENT_ADDRESS, CLIENT_CITY, CLIENT_MAX_HOURS, CLIENT_KM, CLIENT_NOTES
			FROM CLIENT
			LEFT JOIN C_S_STATUS
			ON CLIENT.CLIENT_STATUS = C_S_STATUS.C_S_STATUS_CODE
			LEFT JOIN GROUP_HOME
			ON CLIENT.GH_ID = GROUP_HOME.GH_ID
			WHERE CLIENT.CLIENT_ID = '$id'");
				
			$sql->execute();
			
			$row = $sql->fetch();
			
			//retrieve other statuses from database
			$stasql = $conn->prepare("SELECT * FROM C_S_STATUS WHERE C_S_STATUS_CODE != '{$row['CLIENT_STATUS']}'");
			
			$stasql->execute();
			
			$starow = $stasql->fetchAll();
			
			//retrieve other group homes from database
			$ghsql = $conn->prepare("SELECT GH_ID, GH_NAME FROM GROUP_HOME WHERE GH_ID != '{$row['GH_ID']}'");
			
			$ghsql->execute();
			
			$ghrow = $ghsql->fetchAll();
			
			//include navbar
			include "../includes/scripts/navBar.php";
			echo'<div class="container">';
			echo'<div class="row justify-content-sm-center">';
			//display the form
			printf("

				<form class='form-con' method='post' action='modclient.php'>
				<h1>Modify a Client</h1>

					<!--submit the ID as a hidden value-->
					<input class='form-fan' type='hidden' name='id' value='$id'>
					First Name:
						<input class='form-fan' type='text' name='fname' value='{$row['CLIENT_FNAME']}'> $fnamerr 
					Last Name:
						<input class='form-fan' type='text' name='lname' value='{$row['CLIENT_LNAME']}'> $lnamerr<br /><br />\n

					Primary Phone Number:
						<input class='form-fan' type='tel' name='phone' pattern='[0-9]{3}-[0-9]{3}-[0-9]{4}' value='{$row['CLIENT_PHONE']}'><br />
						Format: 000-000-0000<br /><br />\n
						
					Full Address:
						<input class='form-fan' type='text' name='address' value='{$row['CLIENT_ADDRESS']}'>
					City:
						<input class='form-fan' type='text' name='city' value='{$row['CLIENT_CITY']}'><br /><br />\n
						
					<!--display selection of statuses-->
					Status:
						<select class='fanc' name='status'>
							<option value='{$row['C_S_STATUS_CODE']}'>{$row['C_S_STATUS_NAME']}</option>");
			foreach($starow as $data)
				echo "<option value='{$data['C_S_STATUS_CODE']}'>{$data['C_S_STATUS_NAME']}</option>";
			printf("
						</select><br /><br />\n
						
					<!--display selection of group homes-->	
					Group Home:
						<select class='fanc' name='gh'>
							<option value='{$row['GH_ID']}'>{$row['GH_NAME']}</option>");
			foreach($ghrow as $data)
				echo "<option value='{$data['GH_ID']}'>{$data['GH_NAME']}</option>";
			printf("
						</select><br /><br />\n

					Distance (in kilometers):
						<input class='form-fan' type='text' name='km' value='{$row['CLIENT_KM']}'><br /><br />
						
					Max Hours per Month:
						<input class='form-fan' type='text' name='hours' value='{$row['CLIENT_MAX_HOURS']}'><br /><br />
						
					Notes:
						<textarea class='form-fan' name='notes' rows='3' cols='30'>{$row['CLIENT_NOTES']}</textarea><br /><br />
					
					<input  type='submit' name='submit' value='Submit' class='btn btn-primary'>
					<a href='viewclient.php' class='btn btn-danger'>Cancel</a>

				</form><br />
				
				<!--cancel button that returns user to previous page-->
				
			");
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
echo'
</div>';
	include "../includes/scripts/footer2.php";
	echo'
</body>
</html>
    ';
	?>