<?php
/*  Developer:   Justin Alho
 *  File Name:   addgh.php
 *  Description: Allows coordinators to add new group home records into the database
 *  Date Start:  23/02/2020
 *  Date End:    TBD
 */?>
<?php
echo'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	        <title>Add New Group Home</title>
    <title>Table</title>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/table.css" rel="stylesheet" type="text/css">

</head>
<body>
';
		
			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
		
		 include "../includes/scripts/headLinks2.0.php";
		
	
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//initialize variables
			$super = '';
			$name = '';
			$phone = '';
			$address = '';
			$city = '';
			
			$newerr = '';
			$superr = '';
			$namerr = '';
			$adderr = '';

            //connect to the database
            $username = 'oldcount_edenbridge1';
            $password = 'z}[!IKVm5Ze9';
            $conn = new PDO("mysql:host=localhost; dbname=oldcount_edenbridge", $username, $password);
		
			//if the form has been submitted
			if(isset($_POST['submit']))
			{	
				//set the error counter to 0
				$err = 0;
				
				//set variables to submitted values
				$super = $_POST['super'];
				$name = $_POST['name'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				
				//if required fields are blank, set the corresponding error message and increment error counter
				if($name == '')
				{
					$namerr = 'Please enter a name to identify the group home.';
					$err++;
				}
				
				if($address == '')
				{
					$adderr = 'Please enter an address for the group home.';
					$err++;
				}
				
				if($super == '')
				{
					$superr = 'Please select a supervisor for the group home.';
					$err++;
				}
				
				//check to see if group home already exists
				$checkSql = $conn->prepare("SELECT * FROM GROUP_HOME
				WHERE GH_NAME = '$name'
				OR GH_ADDRESS = '$address'");
				$checkSql->execute();
				$checkRow = $checkSql->fetchall();
				
				//if records already exist, increment error counter and set corresponding error message
				if(sizeof($checkRow) > 0)
				{
					if($checkRow[0]['GH_NAME'] == $name)
					{
						$err++;
						$namerr = 'There is already a group home with that name.';
					}
					if($checkRow[0]['GH_ADDRESS'] == $address)
					{
						$err++;
						$adderr = 'There is already a group home with that address.';
					}
				}
				
				//if there are no errors, add information into the database
				if($err == 0)
				{
					$sql = $conn->prepare("INSERT INTO 	group_home (STAFF_ID, GH_NAME, GH_PHONE, GH_ADDRESS, GH_CITY) VALUES ('$super', '$name', '$phone', '$address', '$city')");
					
					$sql->execute();

					$id = $conn->lastInsertId();
					$code = 'G' . $id;
					$desc = 'The department for ' . $name . '.';
					
					$depsql = $conn->prepare("INSERT INTO department (DEP_CODE, GH_ID, DEP_NAME, DEP_DESC) VALUES ('$code', '$id', '$name', '$desc')");
					$depsql->execute();
					
					//log whenever database is updated
					date_default_timezone_set("US/Mountain");
					//F j, Y, g:i a
					$dateString = date("r");
					file_put_contents("../logs/groupHomeAddLog.txt", "\n" . "Group home " . $name . " was added on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
					
					//echo implode(":",$sql->errorInfo());
					
					//send the user back to this page with an empty form and a success message
					header('Location: addgh.php?s=1');
				}
			}
					
			//retrieve supervisor records from database
			$sql = $conn->prepare("SELECT STAFF_ID, STAFF_FNAME, STAFF_LNAME FROM staff WHERE TYPE_CODE = 'S'");
				
			$sql->execute();
			//echo implode(":",$sql->errorInfo());
			
			$row = $sql->fetchAll();
			
			
			//include navbar
			include "../includes/scripts/navBar.php";
			
			echo'<div class="container">';
			echo'<div class="row justify-content-sm-center">';
	
			//if there is a successful database entry, display message

			
			
			//display the form
			printf("

				

				<form class='form-con' method='post' action='addgh.php'>
				");
				if(isset($_REQUEST['s']))
				echo "Record added successfully.<br /><br />";	
				printf("
				
				<h1>Add New Group Home</h1>

					<!--display selection of supervisors-->
					Supervisor:
						<select class='fanc' name='super'>
							<option value=''>Select a supervisor:</option>");
			foreach($row as $data)
				echo "<option value='{$data['STAFF_ID']}'>{$data['STAFF_FNAME']} {$data['STAFF_LNAME']}</option>";
			printf("
						</select>$superr<br /><br />\n
						
					Group Home Name:
						<input class='form-fan' type='text' name='name' value='$name'>$namerr<br /><br />\n	
					
					Group Home Phone Number:
						<input class='form-fan' type='tel' name='phone' pattern='[0-9]{3}-[0-9]{3}-[0-9]{4}' value='$phone'><br />
						Format: 000-000-0000<br /><br />\n
												
					Group Home Address:
						<input class='form-fan' type='text' name='address' value='$address'>$adderr<br /><br />\n
						
					Group Home City:
						<input class='form-fan' type='text' name='city' value='$city'><br /><br />\n
					
					<input  type='submit' name='submit' value='Submit' class='btn btn-primary'>\n
					<a href='/grouphome/' class='btn btn-danger'>Cancel</a>

				</form>

				<!--cancel button that returns user to previous page-->
			
			");
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			echo'
</div>';
	include "../includes/scripts/footer2.php";
	echo'
</body>
</html>
    ';
	?>