
<html>

<head>

    <title>View Reports</title>
    <?php
    //Starting a session and initializing variables needed
    session_start();
    $userType = $_SESSION['userType'];

    include "../includes/scripts/headLinks2.0.php";
    include "../includes/functions/getHours.php"
    ?>
    <script>
        //this function should take in an id and a total and set the total to the spot with that id

        function setTotal(id, total)
        {
            var total = total.toFixed(1);
            document.getElementById(id).innerHTML = total;
        }

    </script>
</head>

<body>

<?php

//level of authorization required to access page
$authLevel = "B";

//to verify the user
include "../includes/functions/verLogin.php";
verLogin();

//to verify the user's type
include "../includes/functions/valUserType.php";
valUserType($authLevel);

//connect to the database
$username = 'oldcount_edenbridge1';
$password = 'z}[!IKVm5Ze9';
$conn = new PDO("mysql:host=localhost; dbname=oldcount_edenbridge", $username, $password);

$stm = "SELECT SHIFT_ID, SHIFT_DATE, SCHEDULED_START, SCHEDULED_END, SHIFT_DATE, DEP_NAME,
						SHIFT.CLIENT_ID, SHIFT.STAFF_ID, STAFF_LNAME, STAFF_FNAME, CLIENT_LNAME, CLIENT_FNAME
						FROM SHIFT
						LEFT JOIN STAFF
						ON SHIFT.STAFF_ID = STAFF.STAFF_ID
						LEFT JOIN CLIENT
						ON SHIFT.CLIENT_ID = CLIENT.CLIENT_ID
						LEFT JOIN DEPARTMENT
						ON SHIFT.DEP_CODE = DEPARTMENT.DEP_CODE
						WHERE SHIFT_DATE > '2020-04-01'
						AND SHIFT_DATE < '2020-04-15'
						
						";

$orderBy = " ORDER BY STAFF_LNAME, CLIENT_LNAME ASC, SHIFT_DATE ASC, SCHEDULED_START ASC";

//sorting/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if( (isset($_REQUEST['sortBy']) ) && (!isset($_SESSION['sortBy']) ) )
{
    switch($_REQUEST['sortBy'])
    {
        case 'staff':
            $_SESSION['sortBy'] = 'staff';
            $orderBy = " ORDER BY STAFF_LNAME, CLIENT_LNAME, SHIFT_DATE, SCHEDULED_START DESC";
            $stm = $stm . $orderBy;
            break;

        case 'client':
            $_SESSION['sortBy'] = 'client';
            $orderBy = " ORDER BY CLIENT_LNAME, STAFF_LNAME, SHIFT_DATE, SCHEDULED_START DESC";
            $stm = $stm . $orderBy;
            break;

        case 'dep':
            $_SESSION['sortBy'] = 'dep';
            $orderBy = " ORDER BY DEP_NAME, CLIENT_LNAME, STAFF_LNAME, SHIFT_DATE, SCHEDULED_START DESC";
            $stm = $stm . $orderBy;
            break;

        default:

            break;
    }
}
else if( (isset($_REQUEST['sortBy']) ) && (isset($_SESSION['sortBy']) ) )
{
    switch($_REQUEST['sortBy'])
    {
        case 'staff':
            unset($_SESSION['sortBy']);
            $orderBy = " ORDER BY STAFF_LNAME, CLIENT_LNAME, SHIFT_DATE, SCHEDULED_START ASC";
            $stm = $stm . $orderBy;
            break;

        case 'client':
            unset($_SESSION['sortBy']);
            $orderBy = " ORDER BY CLIENT_LNAME, STAFF_LNAME, SHIFT_DATE, SCHEDULED_START ASC";
            $stm = $stm . $orderBy;
            break;

        case 'dep':
            unset($_SESSION['sortBy']);
            $orderBy = " ORDER BY DEP_NAME, CLIENT_LNAME, STAFF_LNAME, SHIFT_DATE, SCHEDULED_START ASC";
            $stm = $stm . $orderBy;
            break;

        default:

            break;
    }
}
else
{
    $stm = $stm . $orderBy;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//select basic information about shifts, ordered first by client, then by date,
//then by start time in case somehow the same staff is scheduled with the same client multiple times in one day
$sql = $conn->prepare($stm);

$sql->execute();

$row = $sql->fetchAll();

//echo implode(":",$sql->errorInfo());

include "../includes/scripts/navBar.php";

//gets the number of days in the month
$days = date('t');
$month = date('F/Y');

echo "
			<div class='container' style='min-height: 85%;'>
			<h1>Hours for Month/Year: $month</h1><br /><br />";

//set up the table
echo "<table border='1'>
			
					<form action='reports.php' method='get' id='staffForm'>
					<input type='hidden' name='sortBy' value='staff'></input>
					</form>
					<form action='reports.php' method='get' id='clientForm'>
						<input type='hidden' name='sortBy' value='client'></input>
					</form>
					<form action='reports.php' method='get' id='depForm'>
					<input type='hidden' name='sortBy' value='dep'></input>
					</form>
					
					<tr>
					<th><button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='staffForm' value='Client'>Staff</button></th>
					<th><button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='clientForm' value='Client'>Client</button></th>
					<th><button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='depForm' value='Client'>Department</button></th>
					<th>Total Hours</th>";

$min = 0;
$max = 0;
//if the date is before the 15th, print the first half of the month
if(date('d') <= 15)
{
    for($i = 1; $i <= 15; $i++)
    {
        echo "<th>$i</th>";
    }
    $max = 15;
    $min = 1;
}
//if the date is after the 15th, print the second half of the month
else
{
    for($i = 16; $i <= $days; $i++)
    {
        echo "<th>$i</th>";
    }
    $max = $days;
    $min = 16;
}
echo "</tr>";

//if there are no shifts, don't show any shifts
if(sizeof($row) == 0)
{
    echo "There are no shifts to show.";
}
else
{
    $lastcli = '';	//lastcli keeps track of the last client that had shifts printed
    $tempmin = 0;	//tempmin keeps track of the earliest date for the timesheet
    $i = 0;			//i is used to iterate through records
    while ($i < sizeof($row))
    {
        //if the record is for a different client than the last record
        if($lastcli != $row[$i]['CLIENT_ID'])
        {
            $tempmin = $min;
            $totHours = 0;

            //set up the row
            echo "<tr>";
            echo "<td>{$row[$i]['STAFF_LNAME']}, {$row[$i]['STAFF_FNAME']}</td>";
            echo "<td>{$row[$i]['CLIENT_LNAME']}, {$row[$i]['CLIENT_FNAME']}</td>";
            echo "<td>{$row[$i]['DEP_NAME']}</td>";
            $totalId = $row[$i]['STAFF_ID'] . '_' . $row[$i]['CLIENT_ID'] . 'tot';
            echo "<td id='$totalId'></td>";

            $j = $i;
            //starting with the current record, until the client is different
            do
            {
                //set the date for the shift
                $date = strtotime($row[$j]['SHIFT_DATE']);
                //until the shift date, fill the timesheet with blank table data
                while($tempmin < date('d', $date))
                {
                    echo "<td></td>";
                    $tempmin++;
                }
                //once the date is reached, print the number of hours
                $numHours = getHours($row[$j]['SCHEDULED_START'], $row[$j]['SCHEDULED_END']);
                $totHours = $totHours + $numHours;

                echo "<td>$numHours</td>";
                $tempmin++;

                $j++;
                //if the next record is the last one, break out of the loop
                if($j >= sizeof($row))
                    break;
            } while ($row[$j]['CLIENT_ID'] == $row[$j-1]['CLIENT_ID']);

            //fill the timesheet with blank table data until the end of the table
            while($tempmin <= $max)
            {
                echo "<td></td>";
                $tempmin++;
            }
            //when all of the start times for that client are filled in, end the row
            echo "</tr>";

            //Fill in the total field
            ?>
            <script>
                var totalId = <?php echo "'$totalId'"; ?>;
                var totHours = <?php echo $totHours; ?>;
                setTotal(totalId, totHours);

                //test
                //document.getElementById("17_6tot").innerHTML = "Test";
            </script>
            <?php

            //set the last client as lastcli, so that their shifts won't be displayed again
            $lastcli = $row[$i]['CLIENT_ID'];
        }

        $i++;
    }
}

//end the table
echo "</table><br />\n";
?>
<script>
    //test
    //document.getElementById("4_2tot").innerHTML = "Test";
</script>
<?php
echo "<a href='../land.php' class='btn btn-secondary'>Back to Home</a>
			</div>";

//releasing database resources
if(isset($conn) )
{
    $conn = null;
}

include "../includes/scripts/footer.php";
?>
</body>
</html>
