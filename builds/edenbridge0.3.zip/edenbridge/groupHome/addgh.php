<html>

    <head>

        <title>Add New Group Home</title>
		<?php 
			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
		?>
		<?php include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			#to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			#test!!!!!!!!!!!!!!!!!!!!!!!1
			#print($authLevel);
			
			#to verify the users type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			
			$super = '';
			$name = '';
			$phone = '';
			$address = '';
			$city = '';
		
			if(isset($_POST['submit']))
			{	
				$super = $_POST['super'];
				$name = $_POST['name'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				
				$username = 'Coordinator';
				$password = 'Password1';
				$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);

				$sql = $conn->prepare("INSERT INTO 	group_home (STAFF_ID, GH_NAME, GH_PHONE, GH_ADDRESS, GH_CITY) VALUES ('$super', '$name', '$phone', '$address', '$city')");
				
				$sql->execute();

				$id = $conn->lastInsertId();
				$code = 'G' . $id;
				$desc = 'The department for ' . $name . '.';
				
				$depsql = $conn->prepare("INSERT INTO department (DEP_CODE, GH_ID, DEP_NAME, DEP_DESC) VALUES ('$code', '$id', '$name', '$desc')");
				$depsql->execute();
				
				//echo implode(":",$sql->errorInfo());
				
				echo "record added successfully.<br /><br />";
			}
			else
			{
				$username = 'Coordinator';
				$password = 'Password1';
				$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
						
				$sql = $conn->prepare("SELECT STAFF_ID, STAFF_FNAME, STAFF_LNAME FROM staff WHERE TYPE_CODE = 'S'");
					
				$sql->execute();
				//echo implode(":",$sql->errorInfo());
				
				$row = $sql->fetchAll();
				
				include "../includes/scripts/navBar.php";
				
				printf("

					<h1>Add New Group Home</h1>

					<form method='post' action='addgh.php'>

						Supervisor:
							<select name='super'>
								<option value=''>Select a supervisor:</option>");
				foreach($row as $data)
					echo "<option value='{$data['STAFF_ID']}'>{$data['STAFF_FNAME']} {$data['STAFF_LNAME']}</option>";
				printf("
							</select><br /><br />\n
							
						Group Home Name:
							<input type='text' name='name' value=''><br /><br />\n	
						
						Group Home Phone Number:
							<input type='text' name='phone' value=''><br /><br />\n
													
						Group Home Address:
							<input type='text' name='address' value=''><br /><br />\n
							
						Group Home City:
							<input type='text' name='city' value=''><br /><br />\n
						
						<input type='submit' name='submit' value='Submit'>\n

					</form>

				");
				
				include "../includes/scripts/footer.php";
			}
        ?>

    </body>

</html>