<?php

			#Starting a session and initilizing variables needed
	
			session_start();
			$userType = $_SESSION['userType'];
					include "../includes/scripts/headLinks2.0.php"; 
					include "../includes/functions/isSpecial.php";
					include "../includes/functions/isComplex.php";
					




        
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			
echo'
<html>
<head>
<title>Help</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/table.css" rel="stylesheet" type="text/css">
	<link href="css/footer.css" rel="stylesheet" type="text/css">
</head>
<body>';


						include "../includes/scripts/navBar.php";

echo'
<div style="padding:20px">
<embed type="application/pdf" src="../includes/images/help page.pdf" style="width:100%; height:96%;"></embed>
</div>
</body>
</html>
';

include "../includes/scripts/footer.php";

?>