<?php
	//The only page in this directory is the reports page,
    //so anyone trying to access this directory directly will get redirected to the reports page.
	header("Location: reports.php");
?>