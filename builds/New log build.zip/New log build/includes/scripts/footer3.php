<?php
/*  Developer:   Evan Guest
 *  File Name:   footer.php
 *  Description: Displays the footer on other pages
 *  Date Start:  04/03/2020
 *  Date End:    04/03/2020
 */
 
	//display header, link to about page
	print('
	
		<div class="footer2">
			<p class="text-white">Copyright Edenbridge Family Services Inc 2020</p>
			<p><a target="_blank" href="../includes/about.html">About</a></p>
		</div>
	');

?>