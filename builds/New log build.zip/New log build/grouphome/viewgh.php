<?php
/*  Developer:   Justin Alho
 *  File Name:   viewgh.php
 *  Description: Allows coordinators to view existing group homes and select to modify them
 *  Date Start:  25/02/2020
 *  Date End:    TBD
 *  TODO:    	 - add sorting, filtering
 */?>
<?php
echo'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	        <title>View Group Home Information</title>
    <title>Table</title>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/table.css" rel="stylesheet" type="text/css">
	
	<style>
		.bodD
		{
			min-height: 85%;
		}
		html, body
		{
			height: 100%;
		}
		
	</style>

</head>
<body>
';
		
			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
		
		 include "../includes/scripts/headLinks2.0.php";
		include "../includes/scripts/navBar.php";
		 echo'
		 <div class="conb">
<div class="row justify-content-center">
<form class="form-con">
    <form>
';
		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);

            //connect to the database
            $username = 'oldcount_edenbridge1';
            $password = 'z}[!IKVm5Ze9';
            $conn = new PDO("mysql:host=localhost; dbname=oldcount_edenbridge", $username, $password);
					
			//retrieve group home information from the database
			$sql = $conn->prepare("SELECT GH_ID, GH_NAME, STAFF_FNAME, STAFF_LNAME, GH_PHONE, GH_ADDRESS, GH_CITY
			FROM GROUP_HOME
			LEFT JOIN STAFF
			ON GROUP_HOME.STAFF_ID = STAFF.STAFF_ID");
				
			$sql->execute();
			
			$row = $sql->fetchAll();
			
			//include navbar
			
			
			//if there is a successful update from modgh.php, display a success message
			if(isset($_REQUEST['p']))
				echo "Group home has been updated successfully.";
			
			//set up table headers
			echo
			"<table border='1'>
				<tr>
					<th>Group Home</th>
					<th>Supervisor</th>
					<th>Phone Number</th>
					<th>Address</th>
					<th>City</th>
					<th></th>
				</tr>
			";
			
			//fill table with records from database
			foreach ($row as $data)
			{	
				echo "<tr>";
				echo "<td>{$data['GH_NAME']}</td>";
				echo "<td>{$data['STAFF_FNAME']} {$data['STAFF_LNAME']}</td>";
				echo "<td>{$data['GH_PHONE']}</td>";
				echo "<td>{$data['GH_ADDRESS']}</td>";
				echo "<td>{$data['GH_CITY']}</td>";
				echo "<td><a href='modgh.php?id={$data['GH_ID']}'class='btn btn-info'>modify</a></td>";
				echo "</tr>";
			}
				
			echo "</table><br />\n";
			
			echo "<a href='/grouphome/' class='btn btn-secondary'>Back</a><br /><br />";
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer\
		
echo'
            

    
			</form>
		</div>';
		
echo'</div>
</div>';
include "../includes/scripts/footer.php";

	echo'
</body>
</html>
    ';
	?>