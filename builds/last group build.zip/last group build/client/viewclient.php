<?php
echo'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Client Information</title>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/table.css" rel="stylesheet" type="text/css">
	
	<style>
		.bodD
		{
			min-height: 85%;
		}
		html, body
		{
			height: 100%;
		}
		
	</style>

</head>
<body>
';

			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];

include "../includes/scripts/headLinks2.0.php";
include "../includes/scripts/navBar.php";
echo'
<div class="bodD">
	<div class="row justify-content-center">

    
';

			//level of authorization required to access page
			$authLevel = "C";
		
			//to verify the user
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);

            //connect to the database
            $username = 'oldcount_edenbridge1';
            $password = 'z}[!IKVm5Ze9';
            $conn = new PDO("mysql:host=localhost; dbname=oldcount_edenbridge", $username, $password);
					
			$stm = "SELECT CLIENT_ID, C_S_STATUS_NAME, GH_NAME, CLIENT_FNAME, CLIENT_LNAME, CLIENT_PHONE, CLIENT_ADDRESS, CLIENT_CITY, CLIENT_MAX_HOURS, CLIENT_KM, CLIENT_NOTES
			FROM CLIENT
			LEFT JOIN C_S_STATUS
			ON CLIENT.CLIENT_STATUS = C_S_STATUS.C_S_STATUS_CODE
			LEFT JOIN GROUP_HOME
			ON CLIENT.GH_ID = GROUP_HOME.GH_ID
			";
			
			$orderBy = " ORDER BY CLIENT_LNAME";
			
			//sorting/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			if( (isset($_REQUEST['sortBy']) ) && (!isset($_SESSION['sortBy']) ) )
			{
				switch($_REQUEST['sortBy'])
				{
					case 'client':
						$_SESSION['sortBy'] = 'client';
						$orderBy = " ORDER BY CLIENT_LNAME DESC";
						$stm = $stm . $orderBy;
						break;

					case 'status':
						$_SESSION['sortBy'] = 'status';
						$orderBy = " ORDER BY C_S_STATUS_NAME DESC";
						$stm = $stm . $orderBy;
						break;

					case 'gHome':
						$_SESSION['sortBy'] = 'type';
						$orderBy = " ORDER BY GH_NAME DESC";
						$stm = $stm . $orderBy;
						break;
						
					case 'city':
						$_SESSION['sortBy'] = 'city';
						$orderBy = " ORDER BY CLIENT_CITY DESC";
						$stm = $stm . $orderBy;
						
						break;
						
					case 'hours':
						$_SESSION['sortBy'] = 'child';
						$orderBy = " ORDER BY CLIENT_MAX_HOURS DESC";
						$stm = $stm . $orderBy;
						
						break;
						
					case 'dist':
						$_SESSION['sortBy'] = 'person';
						$orderBy = " ORDER BY CLIENT_KM DESC";
						$stm = $stm . $orderBy;
						
						break;
						
					case 'drive':
						$_SESSION['sortBy'] = 'drive';
						$orderBy = " ORDER BY CAN_DRIVE DESC";
						$stm = $stm . $orderBy;
						
						break;

					default:

						break;
				}
			}
			else if( (isset($_REQUEST['sortBy']) ) && (isset($_SESSION['sortBy']) ) )
			{
				switch($_REQUEST['sortBy'])
				{
					case 'client':
						unset($_SESSION['sortBy']);
						$orderBy = " ORDER BY CLIENT_LNAME ASC";
						$stm = $stm . $orderBy;
						break;

					case 'status':
						unset($_SESSION['sortBy']);
						$orderBy = " ORDER BY C_S_STATUS_NAME ASC";
						$stm = $stm . $orderBy;
						break;

					case 'gHome':
						unset($_SESSION['sortBy']);
						$orderBy = " ORDER BY GH_NAME ASC";
						$stm = $stm . $orderBy;
						break;
						
					case 'city':
						unset($_SESSION['sortBy']);
						$orderBy = " ORDER BY CLIENT_CITY ASC";
						$stm = $stm . $orderBy;
					
						break;
						
					case 'hours':
						unset($_SESSION['sortBy']);
						$orderBy = " ORDER BY CLIENT_MAX_HOURS ASC";
						$stm = $stm . $orderBy;
					
						break;
						
					case 'dist':
						unset($_SESSION['sortBy']);
						$orderBy = " ORDER BY CLIENT_KM ASC";
						$stm = $stm . $orderBy;
					
						break;
						
					case 'drive':
						unset($_SESSION['sortBy']);
						$orderBy = " ORDER BY CAN_DRIVE ASC";
						$stm = $stm . $orderBy;
					
						break;

					default:

						break;
				}
			}
			else
			{
				$stm = $stm . $orderBy;
			}
			
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				
				
			$sql = $conn->prepare($stm);
			
			$sql->execute();
			
			$row = $sql->fetchAll();
			
		echo'
		
		<div class="form-con">';
			
			if(isset($_REQUEST['s']))
				echo "Client updated successfully.";
			
			echo
			"<table border='1'>
				<form action='viewclient.php' method='get' id='clientForm'>
					<input type='hidden' name='sortBy' value='client'></input>
				</form>
				<form action='viewclient.php' method='get' id='statForm'>
					<input type='hidden' name='sortBy' value='status'></input>
				</form>
				<form action='viewclient.php' method='get' id='gHomeForm'>
					<input type='hidden' name='sortBy' value='gHome'></input>
				</form>
				<form action='viewclient.php' method='get' id='cityForm'>
					<input type='hidden' name='sortBy' value='city'></input>
				</form>
				<form action='viewclient.php' method='get' id='hourForm'>
					<input type='hidden' name='sortBy' value='hours'></input>
				</form>
				<form action='viewclient.php' method='get' id='distForm'>
					<input type='hidden' name='sortBy' value='dist'></input>
				</form>
				
				<tr>
					<th>
						<button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='clientForm' value='client'>Client
						</button>
					</th>
					<th>
						<button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='statForm' value='status'>Status
						</button>
					</th>
					<th>
						<button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='gHomeForm' value='gHome'>Group Home
						</button>
					</th>
					<th>Phone Number</th>
					<th>Address</th>
					<th>
						<button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='cityForm' value='city'>City
						</button>
					</th>
					<th>
						<button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='hourForm' value='hours'>Max Hours per Month
						</button>
					</th>
					<th>
						<button style='background: none;
										border: none;
										padding: 0;
										color: white;
										font-weight: bold;
										text-decoration: none;
										cursor: pointer;' type='submit' form='distForm' value='dist'>Distance (KM)
						</button>
					</th>
					<th>Notes</th>
					<th></th>
				</tr>
			";
			
			foreach ($row as $data)
			{	
				echo "<tr>";
				echo "<td>{$data['CLIENT_LNAME']}, {$data['CLIENT_FNAME']}</td>";
				echo "<td>{$data['C_S_STATUS_NAME']}</td>";
				echo "<td>{$data['GH_NAME']}</td>";
				echo "<td>{$data['CLIENT_PHONE']}</td>";
				echo "<td>{$data['CLIENT_ADDRESS']}</td>";
				echo "<td>{$data['CLIENT_CITY']}</td>";
				echo "<td>{$data['CLIENT_MAX_HOURS']}</td>";
				echo "<td>{$data['CLIENT_KM']}</td>";
				echo "<td>{$data['CLIENT_NOTES']}</td>";
				echo "<td><a href='modclient.php?id={$data['CLIENT_ID']}'class='btn btn-info'>modify</a></td>";
				echo "</tr>";
			}
				
			echo "</table><br />\n";
			
			echo "<a href='/client/' class='btn btn-secondary'>Back</a><br /><br />";
			
			echo'</div>';
		
			
echo'
            

			</form>
		</form>
	</div>
</div>';
include "../includes/scripts/footer.php";
	echo'
</body>
</html>
    ';
	?>