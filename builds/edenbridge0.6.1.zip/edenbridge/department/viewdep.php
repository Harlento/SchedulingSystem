<?php
/*  Developer:   Justin Alho
 *  File Name:   viewdep.php
 *  Description: Allows coordinators to view existing departments and select to modify them
 *  Date Start:  25/02/2020
 *  Date End:    TBD
 *  TODO:    	 - add sorting, filtering
 */?>
<html>

    <head>

        <title>View Department Information</title>
		<?php 
			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//connect to the database
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
			
			//retrieve department information from the database
			$sql = $conn->prepare("SELECT * FROM DEPARTMENT");
				
			$sql->execute();
			
			$row = $sql->fetchAll();
			
			//include navbar
			include "../includes/scripts/navBar.php";

			//if there is a successful update from moddep.php, display a success message
			if(isset($_REQUEST['p']))
				echo "Department updated successfully.";
			
			//set up table headers
			echo
			"<table border='1'>
				<tr>
					<th>Department Code</th>
					<th>Department</th>
					<th>Department Description</th>
					<th></th>
				</tr>
			";
			
			//fill table with records from database
			foreach ($row as $data)
			{
				echo "<tr>";
				echo "<td>{$data['DEP_CODE']}</td>";
				echo "<td>{$data['DEP_NAME']}</td>";
				echo "<td>{$data['DEP_DESC']}</td>";
				echo "<td><a href='moddep.php?code={$data['DEP_CODE']}'>modify</a></td>";
				echo "</tr>";
			}
				
			echo "</table><br />\n";
			
			echo "<a href='/department/' class='btn btn-secondary'>Back</a><br /><br />";
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			include "../includes/scripts/footer.php";
			
		?>
	
	</body>
</html>