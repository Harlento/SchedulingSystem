<?php
//this is a test page!!

$code = "";
$name = "";

echo
"<html>
<head>";

#Starting a session and initilizing variables needed
session_start(); 
$userType = $_SESSION['userType'];
 include "../includes/scripts/headLinks2.0.php";
echo "
</head>
<body>";

//level of authorization required to access page
$authLevel = "C";

#to verify the user 
include "../includes/functions/verLogin.php";
verLogin();

#test!!!!!!!!!!!!!!!!!!!!!!!1
#print($authLevel);

#to verify the users type
include "../includes/functions/valUserType.php";
valUserType($authLevel);

if(isset($_REQUEST['submit']))
{	
	$code=$_REQUEST['code'];
	$name=$_REQUEST['name'];
	
	$username = 'Coordinator';
	$password = 'Password1';
	$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);

	
	$sql = $conn->prepare("INSERT INTO SHIFT_STATUS VALUES ('$code', '$name')");
	
	$sql->execute();
	
	date_default_timezone_set("US/Mountain");
	//F j, Y, g:i a
	$dateString = date("r");
	file_put_contents("../logs/shiftStatAddLog.txt", "\n" . "Shift status " . $name . " was added on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
	
	
	echo "record added successfully.<br /><br />";
}

else
{
	include "../includes/scripts/navBar.php";
	
	echo
	"<form method='post' action='addshiftstatus.php'>
		Code: <input type='text' name='code' /><br /><br />
		Name: <input type='text' name='name' /><br /><br />
		<input type='submit' name='submit' value='add' /><br />
	</form>";
}
echo
"	
	<a href='viewshiftstatus.php'><button>Back to Home</button></a>
";
	
	include "../includes/scripts/footer.php";
	
echo "	
</body>
</html>
";

?>