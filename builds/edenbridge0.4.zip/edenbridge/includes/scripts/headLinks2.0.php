<?php
	print('
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="icon" href="../includes/images/icon.png">
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
		<script src="../js/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
		<script src="../js/popper.min.js" crossorigin="anonymous"></script>
		<script src="../js/bootstrap.min.js" crossorigin="anonymous"></script>
		<link href="../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../css/footer.css" rel="stylesheet" type="text/css">
	');
?>