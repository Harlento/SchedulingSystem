<?php session_start(); ?>
<html>
    
    <head>

        <title>Landing Page</title>
		
		<?php include "./includes/scripts/headLinks.php"; ?>

    </head>
    
    <body>

        

        <?php
			
			#Log in will give them the proper session variables if they are legit
            include "./includes/scripts/logIn.php";
			
			//Setting the userType var
			$userType = $_SESSION['userType'];
			
			//Include navbar
			include "./includes/scripts/navBar.php";

			//echo $userType;
			//echo $userName;
			//echo $password;
			
			#to verify the user 
			include "./includes/functions/verLogin.php";
			verLogin();
			
			//test value
			#$_SESSION['userType'] = 'C';
			
            if(isset($_SESSION['userType']))
            {

                //Custom content based on user type

                $userType = $_SESSION['userType'];

                switch($userType)
                {

                    case "W":
					
						$authLevel = "W";

                        printf("

                            <div>
                                <a href='/shifts/viewSched.php'>Check Schedule</a>
                                <a href='/deadEnd.php'>Submit Hours</a>
                            </div>

                        ");
						include "./includes/scripts/footer.php";


                        //Include footer

                        break;

                    case "B":

                        printf("

                            <a href='/deadEnd.php'>View Reports</a>
                            <a href=''></a>

                        ");
						include "./includes/scripts/footer.php";

                        //Include footer

                        break;

                    case "C":

                        printf('

							<h1>Employees</h1>
                            <a href="/staff/addstaff.php">Add Employee</a><br />
                            <a href="/staff/viewstaff.php">Manage Employees</a><br /><br />
							
							<h1>Clients</h1>
                            <a href="/client/addclient.php">Add Client</a><br />
                            <a href="/client/viewclient.php">Manage Clients</a><br /><br />
							
							<h1>Group Homes</h1>
                            <a href="/grouphome/addgh.php">Add Group Home</a><br />
                            <a href="/grouphome/viewgh.php">Manage Group Homes</a><br /><br />
							
							<h1>Departments</h1>
							<a href="/department/adddep.php">Add Department</a><br />
							<a href="/department/viewdep.php">Manage Departments</a><br /><br />
							
							<h1>Shifts</h1>
                            <a href="/shifts/schedshift.php">Schedule Shift</a><br />
							<a href="/shifts/schedrecshift.php">Schedule Recurring Shifts</a><br />
                            <a href="/shifts/viewshift.php">Manage Shifts</a><br />
							<a href="/shifts/viewrecshift.php">Manage Recurring Shifts</a><br />
							<a href="/shifts/approvetime.php">Approve Hours</a><br /><br />

                        ');
						include "./includes/scripts/footer.php";

                        //Include footer

                        break;

                    case "S":

                        printf("
                        
                            <a href='/index.php'>Modify Shift</a>

                        ");
						include "./includes/scripts/footer.php";

                        break;

                    default:
						//test
						echo "Type code not valid";

                        //header("Location: index.php?message=invalidCreds");
						include "./includes/scripts/footer.php";

                        break;

                }

            }
            else
            {

                //This will be the address of the log in page this is only a placeholder value with a get variable passed through the redirect
                //the variable can be used to change the login page to say "Invalid credentials" or something like that.
				echo "Credentials not valid.";
				include "./includes/scripts/footer.php";
                //header("Location: index.php?message=invalidCreds");

            }

        ?>

    </body>

</html>