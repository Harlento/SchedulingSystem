<?php
/*  Developer:   Justin Alho
 *  File Name:   approvetime.php
 *  Description: Allows coordinators to view list of staff with claimed hours, show hours scheduled/claimed
 *  Date Start:  04/03/2020
 *  Date End:    TBD
 *  TODO:      	 - Add user authentication
 *				 - Add logic to approve shifts
 */
 ?>
<html>

    <head>

        <title>Approve Hours</title>
		<?php 
			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
		?>
		<?php include "../includes/scripts/headLinks2.0.php";
		include "../includes/functions/getHours.php"?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			#to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			#test!!!!!!!!!!!!!!!!!!!!!!!1
			#print($authLevel);
			
			#to verify the users type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
					
			$sql = $conn->prepare("SELECT SHIFT_ID, SHIFT.STATUS_CODE, SHIFT.STAFF_ID, STAFF_FNAME, STAFF_LNAME, SCHEDULED_START, SCHEDULED_END, CLAIMED_START, CLAIMED_END
			FROM SHIFT
			LEFT JOIN SHIFT_STATUS
			ON SHIFT.STATUS_CODE = SHIFT_STATUS.STATUS_CODE
			LEFT JOIN STAFF
			ON SHIFT.STAFF_ID = STAFF.STAFF_ID
			WHERE SHIFT.STATUS_CODE = 'C'
			ORDER BY STAFF_LNAME");
				
			$sql->execute();
			
			$row = $sql->fetchAll();
			
			include "../includes/scripts/navBar.php";
			
			if (sizeof($row) == 0)
			{
				echo "There are no submitted hours to show.";
			}
			else
			{
				echo
				"<table border='1'>
					<tr>
						<th>Staff Name:</th>
						<th>Total Hours Claimed/Scheduled:</th>
						<th>Review Timesheet</th>
						<th>Approve Claimed Hours</th>
					</tr>
				";
				
				$i = 0;
				$st = 0;
				$ct = 0;
				while ($i < sizeof($row))
				{
					if (($i + 1) < sizeof($row))
					{
						if ($row[$i]['STAFF_ID'] == $row[$i+1]['STAFF_ID'])
						{
							$st += getHours($row[$i]['SCHEDULED_START'], $row[$i]['SCHEDULED_END']);
							$ct += getHours($row[$i]['CLAIMED_START'], $row[$i]['CLAIMED_END']);
						}
						else
						{
							$st += getHours($row[$i]['SCHEDULED_START'], $row[$i]['SCHEDULED_END']);
							$ct += getHours($row[$i]['CLAIMED_START'], $row[$i]['CLAIMED_END']);
							if ($st == $ct)
							{
								echo "<tr style='background-color: #AAFFAA'>";
							}
							else
							{
								echo "<tr style='background-color: #FFAAAA'>";
							}
							
							echo "<td>{$row[$i]['STAFF_LNAME']}, {$row[$i]['STAFF_FNAME']}</td>";
							echo "<td>$st/$ct</td>";
							echo "<td><a href='revtime.php'>Review</a></td>";
							echo "<td><a href='approval.php?id={$row[$i]['STAFF_ID']}'>Approve</a></td>";
							$st = 0;
							$ct = 0;
							echo "</tr>";
						}
					}
					else
					{
						$st += getHours($row[$i]['SCHEDULED_START'], $row[$i]['SCHEDULED_END']);
						$ct += getHours($row[$i]['CLAIMED_START'], $row[$i]['CLAIMED_END']);
						if ($st == $ct)
						{
							echo "<tr style='background-color: #AAFFAA'>";
						}
						else
						{
							echo "<tr style='background-color: #FFAAAA'>";
						}
						
						echo "<td>{$row[$i]['STAFF_LNAME']}, {$row[$i]['STAFF_FNAME']}</td>";
						echo "<td>$st/$ct</td>";
						echo "<td><a href='revtime.php'>Review</a></td>";
						echo "<td><a href='approval.php?id={$row[$i]['STAFF_ID']}'>Approve</a></td>";
						$st = 0;
						$ct = 0;
						echo "</tr>";
					}
					$i++;
				}
			}
			include "../includes/scripts/footer.php";
			
		?>
	
	</body>
</html>