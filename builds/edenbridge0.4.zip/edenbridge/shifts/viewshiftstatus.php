<?php

	echo
	"<html>
	<head>
	";
	 
	#Starting a session and initilizing variables needed
	session_start(); 
	$userType = $_SESSION['userType'];
		
	
	include "../includes/scripts/headLinks2.0.php";
	
	echo "
	</head>
	<body>";
	
		//level of authorization required to access page
		$authLevel = "C";
		
		#to verify the user 
		include "../includes/functions/verLogin.php";
		verLogin();
		
		#test!!!!!!!!!!!!!!!!!!!!!!!1
		#print($authLevel);
		
		#to verify the users type
		include "../includes/functions/valUserType.php";
		valUserType($authLevel);
			
			
	$username = 'Coordinator';
	$password = 'Password1';
	$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
			
	$sql = $conn->prepare("SELECT * FROM shift_status");
		
	$sql->execute();
	
	$row = $sql->fetchAll();
	
	include "../includes/scripts/navBar.php";
	
	echo
	"<table border='1'>
		<tr>
			<th>Status Code</th>
			<th>Status Name</th>
		</tr>
	";
	
	foreach ($row as $data)
	{
		echo "<tr>";
		echo "<td>{$data['STATUS_CODE']}</td>";
		echo "<td><a href='modshiftstatus.php?code={$data['STATUS_CODE']}&name={$data['STATUS_NAME']}'>{$data['STATUS_NAME']}</a></td>";
		echo "</tr>";
	}
		
	echo "</table><br />\n";
	
	include "../includes/scripts/footer.php";
		
	echo
	"</body>
	</html>";

?>