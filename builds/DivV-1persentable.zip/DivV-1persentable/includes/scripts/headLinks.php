<?php
	//contains links to css, javascript, etc.
	//included in other pages
	print('
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="icon" href="../includes/images/icon.png"> 
		<script src="js/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
		<script src="js/popper.min.js" crossorigin="anonymous"></script>
		<script src="js/bootstrap.min.js" crossorigin="anonymous"></script>
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="css/footer.css" rel="stylesheet" type="text/css">
	');
?>