<html>
<head>
	<title>Get Available Workers</title>
</head>
<body>
<?php
	//connect to database
	$username = 'Coordinator';
	$password = 'Password1';
	$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
	
	$date = strtotime($_REQUEST['date']);
	$day = date('D', $date);
	$start = $_REQUEST['start'];
	$end = $_REQUEST['end'];
	
	switch($day)
	{
		case 'Sun':
			$dayAvail = 'SUN_AVAIL';
			break;
		case 'Mon':
			$dayAvail = 'MON_AVAIL';
			break;
		case 'Tue':
			$dayAvail = 'TUE_AVAIL';
			break;
		case 'Wed':
			$dayAvail = 'WED_AVAIL';
			break;
		case 'Thu':
			$dayAvail = 'THU_AVAIL';
			break;
		case 'Fri':
			$dayAvail = 'FRI_AVAIL';
			break;
		case 'Sat':
			$dayAvail = 'SAT_AVAIL';
			break;
		default:
			$dayAvail = '';
	}
	
	if(!$dayAvail == '')
	{
		$avsql = $conn->prepare("SELECT * FROM STAFF
		WHERE '$dayAvail' != ''
		OR '$dayAvail' != ' - '");
		
		$avsql->execute();
		$avrow = $avsql->fetchAll;
		
		foreach($avrow as $data)
		{
			print_r($data);
			echo "<br />";
		}
	}
?>
</body>
</html>