
<html>

    <head>

        <title>View Reports</title>
		<?php 
			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
			include "../includes/scripts/headLinks2.0.php";
			include "../includes/functions/getHours.php"
		?>
		<script>
			//this function should take in an id and a total and set the total to the spot with that id
			
			function setTotal(id, total)
			{
				document.getElementById(id).innerHTML = total;
			}
			
		</script>
    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "B";
			
			#to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			#to verify the users type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);

			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);

			//select basic information about shifts, ordered first by client, then by date,
			//then by start time in case somehow the same staff is scheduled with the same client multiple times in one day
			$sql = $conn->prepare("SELECT SHIFT_ID, SHIFT_DATE, SCHEDULED_START, SCHEDULED_END, SHIFT_DATE, DEP_NAME,
						SHIFT.CLIENT_ID, SHIFT.STAFF_ID, STAFF_LNAME, STAFF_FNAME, CLIENT_LNAME, CLIENT_FNAME
						FROM SHIFT
						LEFT JOIN STAFF
						ON SHIFT.STAFF_ID = STAFF.STAFF_ID
						LEFT JOIN CLIENT
						ON SHIFT.CLIENT_ID = CLIENT.CLIENT_ID
						LEFT JOIN DEPARTMENT
						ON SHIFT.DEP_CODE = DEPARTMENT.DEP_CODE
						WHERE SHIFT_DATE > '2020-03-01'
						AND SHIFT_DATE < '2020-03-15'
						ORDER BY STAFF_LNAME, CLIENT_LNAME ASC, SHIFT_DATE ASC, SCHEDULED_START ASC
						");

			$sql->execute();

			$row = $sql->fetchAll();

			//echo implode(":",$sql->errorInfo());

			include "../includes/scripts/navBar.php";

			//gets the number of days in the month
			$days = date('t');
			
			echo "<h1>Hours for 2020 March 01 - 2020 March 15</h1>
			<h3>When complete, this page will allow users to filter which fields they want displayed,</h3>
			<h3>as well as what order they want them in.</h3>";
			
			//set up the table
			echo "<table border='1'>
					<tr>
					<th>Staff:</th>
					<th>Client:</th>
					<th>Department:</th>
					<th>Total Hours:</th>";
			
			$min = 0;
			$max = 0;
			//if the date is before the 15th, print the first half of the month
			if(date('d') <= 15)
			{
				for($i = 1; $i <= 15; $i++)
				{
					echo "<th>$i</th>";
				}
				$max = 15;
				$min = 1;
			}
			//if the date is after the 15th, print the second half of the month
			else
			{
				for($i = 16; $i <= $days; $i++)
				{
					echo "<th>$i</th>";
				}
				$max = $days;
				$min = 16;
			}
			echo "</tr>";
			
			//if there are no shifts, don't show any shifts
			if(sizeof($row) == 0)
			{
				echo "You have no unsubmitted hours.";
			}
			else
			{
				$lastcli = '';	//lastcli keeps track of the last client that had shifts printed
				$tempmin = 0;	//tempmin keeps track of the earliest date for the timesheet
				$i = 0;			//i is used to iterate through records
				while ($i < sizeof($row))
				{
					//if the record is for a different client than the last record
					if($lastcli != $row[$i]['CLIENT_ID'])
					{
						$tempmin = $min;
						$totHours = 0;
						
						//set up the row
						echo "<tr>";
						echo "<td>{$row[$i]['STAFF_LNAME']}, {$row[$i]['STAFF_FNAME']}</td>";
						echo "<td>{$row[$i]['CLIENT_LNAME']}, {$row[$i]['CLIENT_FNAME']}</td>";
						echo "<td>{$row[$i]['DEP_NAME']}</td>";
						$totalId = $row[$i]['STAFF_ID'] . '_' . $row[$i]['CLIENT_ID'] . 'tot';
						echo "<td id='$totalId'></td>";
						
						$j = $i;
						//starting with the current record, until the client is different
						do
						{
							//set the date for the shift
							$date = strtotime($row[$j]['SHIFT_DATE']);
							//until the shift date, fill the timesheet with blank table data
							while($tempmin < date('d', $date))
							{
								echo "<td></td>";
								$tempmin++;
							}
							//once the date is reached, print the number of hours
							$numHours = getHours($row[$j]['SCHEDULED_START'], $row[$j]['SCHEDULED_END']);
							$totHours = $totHours + $numHours;
							
							echo "<td>$numHours</td>";
							$tempmin++;
							
							$j++;
							//if the next record is the last one, break out of the loop
							if($j >= sizeof($row))
								break;
						} while ($row[$j]['CLIENT_ID'] == $row[$j-1]['CLIENT_ID']);
						
						//fill the timesheet with blank table data until the end of the table
						while($tempmin <= $max)
						{
							echo "<td></td>";
							$tempmin++;
						}
						//when all of the start times for that client are filled in, end the row 
						echo "</tr>";
						
						//Fill in the total field
						?>
						<script>
							var totalId = <?php echo "'$totalId'"; ?>;
							var totHours = <?php echo $totHours; ?>;
							setTotal(totalId, totHours);
							
							//test
							//document.getElementById("17_6tot").innerHTML = "Test";
						</script>
						<?php
						
						//set the last client as lastcli, so that their shifts won't be displayed again
						$lastcli = $row[$i]['CLIENT_ID'];
					}
					
					$i++;
				}
			}
			
			//end the table
			echo "</table><br />\n";
			?>
			<script>
				//test
				//document.getElementById("4_2tot").innerHTML = "Test";
			</script>
			<?php
			echo "<a href='../land.php'><button>Back to Home</button></a>";
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			include "../includes/scripts/footer.php";
		?>
	</body>
</html>
