<?php
	//nobody should be able to access this directory directly,
	//so they get redirected to the login screen if they try
	header("Location: /index.php");
?>