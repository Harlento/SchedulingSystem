<?php
	/*  Developer:   Justin Alho
	 *  File Name:   getHours.php
	 *  Description: Defines the getHours function
	 *  Date Start:  02/03/2020
	 *  Date End:    02/03/2020
	 */
	 
	//This function takes a start and end time and returns the number of hours between the two as a decimal.
	function getHours($start, $end)
	{
		$diff = strtotime($end) - strtotime($start);
		$hours = date('h', $diff);
		$mins = date('i', $diff);
		$hours = ($hours + ($mins / 60));
		$hours = number_format($hours, 1);
		return $hours;
	}
?>