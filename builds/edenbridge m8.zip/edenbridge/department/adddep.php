<?php
/*  Developer:   Justin Alho
 *  File Name:   adddep.php
 *  Description: Allows coordinators to add new department records into the database
 *  Date Start:  23/02/2020
 *  Date End:    TBD
 */?>
<html>

    <head>

        <title>Add New Department</title>
		<?php 
			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
			
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//initialize variables
			$code = '';
			$name = '';
			$desc = '';
			
			$coderr = '';
			$namerr = '';
		
			//if the form has been submitted
			if(isset($_POST['submit']))
			{	
				//set error counter to 0
				$err = 0;
				
				//set variables to submitted values
				$code = $_POST['code'];
				$name = $_POST['name'];
				$desc = $_POST['desc'];
				
				//if the code is blank or longer than 3 characters,
				//increment the error counter and set the code error message
				if($code == '' || strlen($code) > 3)
				{
					$coderr = 'Please enter a valid 3-character code.';
					$err ++;
				}
				
				//if the name of the department is blank,
				//increment the error counter and set the name error message
				if($name == '')
				{
					$namerr = 'Please enter a name for the department.';
					$err ++;
				}
				
				//if there are no errors, add information into the database
				if($err == 0)
				{
					//connect to the database
					$username = 'Coordinator';
					$password = 'Password1';
					$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);

					$sql = $conn->prepare("INSERT INTO 	department (DEP_CODE, DEP_NAME, DEP_DESC) VALUES ('$code', '$name', '$desc')");
					
					$sql->execute();
					
					//log whenever the database is updated
					date_default_timezone_set("US/Mountain");
					//F j, Y, g:i a
					$dateString = date("r");
					file_put_contents("../logs/departmentAddLog.txt", "\n" . "Department " . $name . " was added on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
					
					//echo implode(":",$sql->errorInfo());
					
					//send the user back to this page with an empty form and a success message
					header('Location: adddep.php?s=1');
				}
			}	
			
			//include navbar
			include "../includes/scripts/navBar.php";
				
			//if there is a successful database entry, display message
			if(isset($_REQUEST['s']))
				echo "Record added successfully.<br /><br />";	
			
			//display the form
			printf("

				<h1>Add New Department</h1>

				<form method='post' action='adddep.php'>
						
					Department Code:
						<input type='text' name='code' value='$code'>$coderr<br />
						Department codes must be 3 characters or less<br /><br />\n	
						
					Department Name:
						<input type='text' name='name' value='$name'>$namerr<br /><br />\n

					Department Description:<br />
						<textarea name='desc' rows='2' cols='20'></textarea><br /><br />\n

					<input type='submit' name='submit' value='Submit'>\n

				</form>
				
				<!--cancel button that returns user to previous page-->
				<a href='/department/' class='btn btn-danger'>Cancel</a>
			");
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			include "../includes/scripts/footer.php";
        ?>

    </body>

</html>