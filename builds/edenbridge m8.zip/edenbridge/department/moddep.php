<?php
/*  Developer:   Justin Alho
 *  File Name:   moddep.php
 *  Description: Allows coordinators to modify existing department records
 *  Date Start:  25/02/2020
 *  Date End:    TBD
 */?>
<html>

    <head>

        <title>Modify Department</title>
		<?php 
			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
			
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//connect to the database
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
			
			//initialize variables
			$code = '';
			$name = '';
			$desc = '';
			
			$namerr = '';
		
			//if the form has been submitted
			if(isset($_POST['submit']))
			{	
				//set error counter to 0
				$err = 0;
				
				//set variables to submitted values
				$code = $_POST['code'];
				$name = $_POST['name'];
				$desc = $_POST['desc'];
				
				//if name is blank, increment error counter and set name error message
				if($name == '')
				{
					$namerr = 'Please enter a name for the department.';
					$err++;
				}
				
				//if there are no errors, add information into database
				if($err == 0)
				{
					$sql = $conn->prepare("UPDATE DEPARTMENT SET DEP_NAME = '$name', DEP_DESC = '$desc' WHERE DEP_CODE = '$code'");
					
					$sql->execute();
					
					//log whenever the database is updated
					date_default_timezone_set("US/Mountain");
					//F j, Y, g:i a
					$dateString = date("r");
					file_put_contents("../logs/departmentModLog.txt", "\n" . "Department " . $name . " was modified on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
					
					//echo implode(":",$sql->errorInfo());
					
					//send user back to list of departments with a success message
					header("Location: viewdep.php?p=1");
				}
			}
			
			//set code variable to code sent by viewgh.php
			$code = $_REQUEST['code'];
					
			//retrieve selected group home's information from database
			$sql = $conn->prepare("SELECT * FROM DEPARTMENT WHERE DEP_CODE = '$code'");
				
			$sql->execute();
			
			$row = $sql->fetch();
			
			//include navbar
			include "../includes/scripts/navBar.php";
			
			//display the form
			printf("

				<h1>Modify Department</h1>

				<form method='post' action='moddep.php'>
						
					Department Code: $code<br /><br />\n
					<input type='hidden' name='code' value='$code'>
						
					Department Name:
						<input type='text' name='name' value='{$row['DEP_NAME']}'>$namerr<br /><br />\n

					Department Description:<br />
						<textarea name='desc' rows='2' cols='20'>{$row['DEP_DESC']}</textarea><br /><br />\n

					<input type='submit' name='submit' value='Update'>\n

				</form>

				<!--cancel button that returns user to previous page-->
				<a href='viewdep.php' class='btn btn-danger'>Cancel</a>
			");
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			include "../includes/scripts/footer.php";
        ?>

    </body>

</html>