<?php
/*  Developer:   Justin Alho
 *  File Name:   addclient.php
 *  Description: Allows coordinators to add new client records into the database
 *  Date Start:  25/02/2020
 *  Date End:    TBD
 */?>
<html>

    <head>

        <title>Add New Client</title>
		<?php 
			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
			
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php";
			?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
		
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//initialize variables
			$gh = '';
			$fname = '';
			$lname = '';
			$phone = '';
			$address = '';
			$city = '';
			$hours = 0;
			$km = 0;
			$notes = '';
			
			$gherr = '';
			$fnamerr = '';
			$lnamerr = '';
			
			//connect to the database
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
		
			//if the form has been submitted
			if(isset($_POST['submit']))
			{	
				//set error counter to 0
				$err = 0;
				
				//set variables to submitted values
				$gh = $_POST['gh'];
				$fname = $_POST['fname'];
				$lname = $_POST['lname'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				$hours = $_POST['hours'];
				$km = $_POST['km'];
				$notes = addslashes($_POST['notes']);
				
				//if required fields are blank, set the corresponding error message and increment error counter
				if($gh == '')
				{
					$gherr = 'Please select a group home or N/A';
					$err++;
				}
				if($fname == '')
				{
					$fnamerr = 'Please enter a first name.';
					$err++;
				}
				if($lname == '')
				{
					$lnamerr = 'Please enter a last name.';
					$err++;
				}
				
				//if there are no errors, add information into database
				if($err == 0)
				{
					$addsql = $conn->prepare("INSERT INTO CLIENT (GH_ID, CLIENT_FNAME, CLIENT_LNAME, CLIENT_PHONE, CLIENT_ADDRESS, CLIENT_CITY, CLIENT_MAX_HOURS, CLIENT_KM, CLIENT_NOTES)
					VALUES ('$gh', '$fname', '$lname', '$phone', '$address', '$city', '$hours', '$km', '$notes')");
					
					$addsql->execute();
					
					//echo implode(":",$addsql->errorInfo());
					
					//log whenever the database is updated
					date_default_timezone_set("US/Mountain");
					//F j, Y, g:i a
					$dateString = date("r");
					file_put_contents("../logs/clientAddLog.txt", "\n" . $fname . " " . $lname . " was added as a client on: " . $dateString, FILE_APPEND | LOCK_EX);
					
					//send the user back to this page with an empty form and a success message
					header('Location: addclient.php?s=1');
				}
			}
			
			//select group home records from database
			$sql = $conn->prepare("SELECT * FROM group_home");
				
			$sql->execute();
			
			$row = $sql->fetchAll();
			
			//inlude navbar
			include "../includes/scripts/navBar.php";
			
			//if there is a successful database entry, display message
			if(isset($_REQUEST['s']))
				echo "Record added successfully.<br /><br />";
			
			//display the form
			printf("
				
				<h1>Add New Client</h1>

				<form method='post' action='addclient.php'>

				First Name:
					<input type='text' name='fname' value='$fname'>$fnamerr
				Last Name:
					<input type='text' name='lname' value='$lname'>$lnamerr<br /><br />\n
				Full Address:
					<input type='text' name='address' value='$address'>
				City:
					<input type='text' name='city' value='$city'><br /><br />\n
				Phone Number:
					<input type='tel' name='phone' pattern='[0-9]{3}-[0-9]{3}-[0-9]{4}' value='$phone'><br />
					Format: 000-000-0000<br /><br />\n
					
				<!--display selection of group homes-->
				Group Home:
					<select name='gh'>
						<option value=''>Select a Group Home:</option>");
			foreach($row as $data)
				echo "<option value='{$data['GH_ID']}'>{$data['GH_NAME']}</option>";
			printf("
					</select>$gherr<br /><br />
				Hours Per Month:
					<input type='text' name='hours' value='$hours'><br /><br /><br />\n
				Distance (in kilometers):
					<input type='text' name='km' value='$km'><br /><br /><br />\n
				Notes:<br />
					<textarea name='notes' rows='3' cols='30'>$notes</textarea><br /><br />\n

					<input type='submit' name='submit' value='Submit'>

				</form><br />
				
				<!--cancel button that returns user to previous page-->
				<a href='/client/' class='btn btn-danger'>Cancel</a>
			");
			
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			include "../includes/scripts/footer.php";
			
        ?>

    </body>

</html>