<?php
/*  Developer:   Justin Alho
 *  File Name:   schedshift.php
 *  Description: Allows coordinators to schedule new shifts
 *  Date Start:  24/02/2020
 *  Date End:    TBD
 */?>
<html>

    <head>

        <title>Schedule a New Shift</title>
		<?php 
			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//initialize variables
			$dep = '';
			$client = '';
			$staff = '';
			$date = '';
			$start = '';
			$end = '';
			$super = '';
			$notes = '';
			
			$deperr = '';
			$clierr = '';
			$staerr = '';
			$daterr = '';
			$sterr = '';
			$enderr = '';
			
			//connect to database
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
		
			//if the form has been submitted
			if(isset($_POST['submit']))
			{
				//set error counter to 0
				$err = 0;
				
				//if the box for recurring shift has been checked
				if(isset($_POST['rec']))
				{
					//set variables to submitted values
					$dep = $_POST['dep'];
					$client = $_POST['client'];
					$staff = $_POST['staff'];
					$date = strtotime($_POST['date']);
					$stdate = $_POST['date'];
					$day = date('D', $date);
					$start = $_POST['start'];
					$end = $_POST['end'];
					if(isset($_POST['super']))
						$super = 1;
					else
						$super = 0;
					$notes = $_POST['notes'];
					
					//if required fields are blank, set the corresponding error message and increment error counter
					if($dep == '')
					{
						$deperr = 'Please select a department.';
						$err++;
					}
					if($client == '')
					{
						$clierr = 'Please select a client.';
						$err++;
					}
					if($staff == '')
					{
						$staerr = 'Please select a staff member.';
						$err++;
					}
					if($date == '')
					{
						$daterr = 'Please select a date.';
						$err++;
					}
					if($start == '')
					{
						$sterr = 'Please choose a start time.';
						$err++;
					}
					if($end == '' || strtotime($end) < strtotime($start))
					{
						$enderr = 'Please choose a valid end time.';
						$err++;
					}
					
					//if there are no errors, create recurring shift record
					if($err == 0)
					{
						$sql = $conn->prepare("INSERT INTO REC_SHIFT (DEP_CODE, CLIENT_ID, STAFF_ID, REC_DAY, REC_START, REC_END, REC_SUPER, REC_NOTES)
						VALUES ('$dep', '$client', '$staff', '$day', '$start', '$end', '$super', '$notes')");
						$exeParams = array($client);
						
						//retrieve client information from database
						$sql2 = $conn->prepare("
											SELECT CLIENT_FNAME, CLIENT_LNAME
											FROM CLIENT
											WHERE CLIENT_ID = ?
										");
						$sql->execute();
						
						$sql2->execute($exeParams);
						
						$row = $sql2->fetch();
						
						//log every time database is updated
						date_default_timezone_set("US/Mountain");
						//F j, Y, g:i a
						$dateString = date("r");
						file_put_contents("../logs/shiftSchedLog.txt", "\n" . "Recurring shift for " . $row['CLIENT_FNAME'] . " " . $row['CLIENT_LNAME'] . " on " . $date . " from " . $start . " to " . $end . " was scheduled on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
						
						//echo implode(":",$sql->errorInfo());
						
						//retrieve the auto-generated recurrence ID
						$recid = $conn->lastInsertId();
						
						//send the user to schedrecshift.php with the ID of the recurring shift as well as the start date
						header("Location: schedrecshift.php?recid=$recid&st=$stdate");
					}
				}
				//if the shift is not a recurring shift
				else
				{
					//set variables to submitted values
					$dep = $_POST['dep'];
					$client = $_POST['client'];
					$staff = $_POST['staff'];
					$date = $_POST['date'];
					$start = $_POST['start'];
					$end = $_POST['end'];
					if(isset($_POST['super']))
						$super = 1;
					else
						$super = 0;
					$notes = $_POST['notes'];

					//if required fields are blank, set the corresponding error message and increment error counter
					if($dep == '')
					{
						$deperr = 'Please select a department.';
						$err++;
					}
					if($client == '')
					{
						$clierr = 'Please select a client.';
						$err++;
					}
					if($staff == '')
					{
						$staerr = 'Please select a staff member.';
						$err++;
					}
					if($date == '')
					{
						$daterr = 'Please select a date.';
						$err++;
					}
					if($start == '')
					{
						$sterr = 'Please choose a start time.';
						$err++;
					}
					if($end == '' || strtotime($end) <= strtotime($start))
					{
						$enderr = 'Please choose a valid end time.';
						$err++;
					}

					//if there are no errors, create shift record
					if($err == 0)
					{
						$sql = $conn->prepare("INSERT INTO SHIFT (DEP_CODE, CLIENT_ID, STAFF_ID, SHIFT_DATE, SCHEDULED_START, SCHEDULED_END, SHIFT_SUPER, SHIFT_NOTES)
						VALUES ('$dep', '$client', '$staff', '$date', '$start', '$end', '$super', '$notes')");
						$sql->execute();
						
						//retrieve client information from database
						$sql2 = $conn->prepare("
											SELECT CLIENT_FNAME, CLIENT_LNAME
											FROM CLIENT
											WHERE CLIENT_ID = ?
										");
						$exeParams = array($client);
						$sql2->execute($exeParams);
						
						$row = $sql2->fetch();
						//$day = date('D', $date);
						
						//log whenever database is updated
						date_default_timezone_set("US/Mountain");
						//F j, Y, g:i a
						$dateString = date("r");
						file_put_contents("../logs/shiftSchedLog.txt", "\n" . "Shift for " . $row['CLIENT_FNAME'] . " " . $row['CLIENT_LNAME'] . " on " . $date . " from " . $start . " to " . $end . " was scheduled on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
						
						//echo implode(":",$sql->errorInfo());
						
						//send users back to this page with an empty form and a success message
						header("Location: schedshift.php?s=1");
					}
				}
			}
			
			//retrieve list of departments from database
			$depsql = $conn->prepare("SELECT * FROM department");
			
			//retrieve list of clients from database
			$clisql = $conn->prepare("SELECT * FROM client where CLIENT_STATUS = 'A'");
			
			//retrieve list of staff from database
			$stasql = $conn->prepare("SELECT * FROM staff where STAFF_STATUS = 'A'");
				
			$depsql->execute();
			$deprow = $depsql->fetchAll();
			$clisql->execute();
			$clirow = $clisql->fetchAll();
			$stasql->execute();
			$starow = $stasql->fetchAll();
			
			//include navbar
			include "../includes/scripts/navBar.php";
			
			//if an individual shift was created successfully, display success message
			if(isset($_REQUEST['s']))
				echo "Shift scheduled successfully.<br /><br />";
			//if recurring shifts were created successfully, display success message
			if(isset($_REQUEST['r']))
				echo "Shifts scheduled successfully.<br /><br />";
			//if recurring shift record was created but shhifts were not created from it, display this message
			if(isset($_REQUEST['c']))
				echo "Recurring Shift Record created successfully.<br />
					  To schedule shifts based on it, go to 'Schedule Recurring Shifts'<br />
					  and select the department it was scheduled for.<br /><br />";
			
			//display the form
			printf("

				<h1>Schedule a New Shift</h1>

				<form method='post' action='schedshift.php'>

					Search for Client:
						<input type='' name='' value=''><br /><br />\n

					<!--display selection of clients-->
					Client Results:
						<select name='client'>
							<option value=''>Select a Client:</option>");
			foreach($clirow as $data)
				echo "<option value='{$data['CLIENT_ID']}'>{$data['CLIENT_FNAME']} {$data['CLIENT_LNAME']}</option>";
			printf("
						</select>$clierr<br /><br />\n

					<!--display selection of departments-->
					Department:
						<select name='dep'>
							<option value=''>Select a Department:</option>");
			foreach($deprow as $data)
				echo "<option value='{$data['DEP_CODE']}'>{$data['DEP_NAME']}</option>";
			printf("
						</select>$deperr<br /><br />\n

					Shift Date:
						<input type='date' name='date' value='$date'>$daterr<br /><br />\n
						
					Recurring Shift: ");
				if(isset($_POST['rec']))
					echo "<input type='checkbox' name='rec' checked />";
				else
					echo "<input type='checkbox' name='rec' />";
				printf("
					A recurring shift will repeat once a week on the weekday selected.<br /><br />

					Start Time:
						<input type='time' name='start' value='$start'>$sterr<br /><br />\n

					End Time:
						<input type='time' name='end' value='$end'>$enderr<br /><br />\n

					Search for Staff:
						<input type='text' name='' value=''><br /><br />\n

					<!--display selection of staff members-->
					Staff results:
						<select name='staff'>
							<option value=''>Select a Staff Member:</option>");
			foreach($starow as $data)
				echo "<option value='{$data['STAFF_ID']}'>{$data['STAFF_FNAME']} {$data['STAFF_LNAME']}</option>";
			printf("
						</select>$staerr<br /><br />\n

						Supervisor: ");
				if(isset($_POST['super']))
					echo "<input type='checkbox' name='super' checked><br /><br />";
				else
					echo "<input type='checkbox' name='super'><br /><br />

					Shift Notes:<br />
						<textarea name='notes' rows='3' cols='30'>$notes</textarea><br /><br />\n

					<input type='submit' name='submit' value='Submit'>

				</form><br />
				
				<!--cancel button that returns user to previous page-->
				<a href='/shifts/' class='btn btn-danger'>Cancel</a>";
				
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			include "../includes/scripts/footer.php";
        ?>

    </body>

</html>