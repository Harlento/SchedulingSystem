<?php
/*  Developer:   Justin Alho
 *  File Name:   modgh.php
 *  Description: Allows coordinators to modify existing group home records
 *  Date Start:  25/02/2020
 *  Date End:    TBD
 */?>
<html>

    <head>

        <title>Modify Group Home</title>
		<?php 
			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
			
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//connect to the database
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
			
			//initialize variables
			$id = '';
			$super = '';
			$name = '';
			$phone = '';
			$address = '';
			$city = '';
			
			$namerr = '';
		
			//if the form has been submitted
			if(isset($_POST['submit']))
			{
				//set error counter to 0
				$err = 0;
				
				//set variables to submitted values
				$id = $_POST['id'];
				$super = $_POST['super'];
				$name = $_POST['name'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				
				//if name is blank, increment error counter and set name error message
				if($name == '')
				{
					$namerr = 'Please enter a name to identify the group home.';
					$err++;
				}
				
				//if there are no errors, add information into database
				if($err == 0)
				{
					$sql = $conn->prepare("UPDATE GROUP_HOME SET STAFF_ID = '$super', GH_NAME = '$name', GH_PHONE = '$phone', GH_ADDRESS = '$address', GH_CITY = '$city' WHERE GH_ID = '$id'");
					
					//set the description for the corresponding department record
					$desc = 'This is the department for ' . $name . '.';
					
					//update department record
					$depsql = $conn->prepare("UPDATE DEPARTMENT SET DEP_NAME = '$name', DEP_DESC = '$desc' WHERE GH_ID = '$id'");
					
					$sql->execute();
					$depsql->execute();
					
					//log whenever the database is updated
					date_default_timezone_set("US/Mountain");
					//F j, Y, g:i a
					$dateString = date("r");
					file_put_contents("../logs/groupHomeModLog.txt", "\n" . "Group home " . $name . " was modified on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
					
					//echo implode(":",$sql->errorInfo()) . "<br>";
					
					//send user back to list of group homes with a success message
					header("Location: viewgh.php?p=1");
				}
			}
			
			//set ID variable to ID sent by viewgh.php
			$id = $_REQUEST['id'];
					
			//retrieve selected group home's information from database
			$sql = $conn->prepare("SELECT GH_ID, GROUP_HOME.STAFF_ID, STAFF_FNAME, STAFF_LNAME, GH_NAME, GH_PHONE, GH_ADDRESS, GH_CITY
			FROM GROUP_HOME
			LEFT JOIN STAFF
			ON GROUP_HOME.STAFF_ID = STAFF.STAFF_ID
			WHERE GH_ID = '$id'");
				
			$sql->execute();
			
			$row = $sql->fetch();
			
			//retrieve list of supervisors from database
			$supsql = $conn->prepare("SELECT STAFF_ID, STAFF_FNAME, STAFF_LNAME FROM STAFF WHERE TYPE_CODE = 'S'");
			
			$supsql->execute();
			
			$suprow = $supsql->fetchAll();
			
			//include navbar
			include "../includes/scripts/navBar.php";
			
			//display the form
			printf("

				<h1>Modify Group Home</h1>

				<form method='post' action='modgh.php'>
						
					<input type='hidden' name='id' value='$id'>
						
					Group Home Name:
						<input type='text' name='name' value='{$row['GH_NAME']}'>$namerr<br /><br />\n
						
					<!--display selection of supervisors-->
					Supervisor:
						<select name='super'>
							<option value='{$row['STAFF_ID']}'>{$row['STAFF_FNAME']} {$row['STAFF_LNAME']}</option>");
			foreach($suprow as $data)
				echo "<option value='{$data['STAFF_ID']}'>{$data['STAFF_FNAME']} {$data['STAFF_LNAME']}</option>";
			printf("
						</select><br /><br />\n
						
					Group Home Phone:
						<input type='tel' name='phone' pattern='[0-9]{3}-[0-9]{3}-[0-9]{4}' value='{$row['GH_PHONE']}'><br />
						Format: 000-000-0000<br /><br />\n

					Group Home Address:
						<input type='text' name='address' value='{$row['GH_ADDRESS']}'><br /><br />\n
						
					Group Home City:
						<input type='text' name='city' value='{$row['GH_CITY']}'><br /><br />\n
						
					<input type='submit' name='submit' value='Update'>\n

				</form>

				<!--cancel button that returns user to previous page-->
				<a href='viewgh.php' class='btn btn-danger'>Cancel</a>
			");
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			include "../includes/scripts/footer.php";
        ?>

    </body>

</html>