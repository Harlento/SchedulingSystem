<?php
/*  Developer:   Justin Alho
 *  File Name:   viewgh.php
 *  Description: Allows coordinators to view existing group homes and select to modify them
 *  Date Start:  25/02/2020
 *  Date End:    TBD
 *  TODO:    	 - add sorting, filtering
 */?>
<html>

    <head>

        <title>View Group Home Information</title>
		<?php 
			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
			
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//connect to the database
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
					
			//retrieve group home information from the database
			$sql = $conn->prepare("SELECT GH_ID, GH_NAME, STAFF_FNAME, STAFF_LNAME, GH_PHONE, GH_ADDRESS, GH_CITY
			FROM GROUP_HOME
			LEFT JOIN STAFF
			ON GROUP_HOME.STAFF_ID = STAFF.STAFF_ID");
				
			$sql->execute();
			
			$row = $sql->fetchAll();
			
			//include navbar
			include "../includes/scripts/navBar.php";
			
			//if there is a successful update from modgh.php, display a success message
			if(isset($_REQUEST['p']))
				echo "Group home has been updated successfully.";
			
			//set up table headers
			echo
			"<table border='1'>
				<tr>
					<th>Group Home</th>
					<th>Supervisor</th>
					<th>Phone Number</th>
					<th>Address</th>
					<th>City</th>
					<th></th>
				</tr>
			";
			
			//fill table with records from database
			foreach ($row as $data)
			{	
				echo "<tr>";
				echo "<td>{$data['GH_NAME']}</td>";
				echo "<td>{$data['STAFF_FNAME']} {$data['STAFF_LNAME']}</td>";
				echo "<td>{$data['GH_PHONE']}</td>";
				echo "<td>{$data['GH_ADDRESS']}</td>";
				echo "<td>{$data['GH_CITY']}</td>";
				echo "<td><a href='modgh.php?id={$data['GH_ID']}'>modify</a></td>";
				echo "</tr>";
			}
				
			echo "</table><br />\n";
			
			echo "<a href='/grouphome/' class='btn btn-secondary'>Back</a><br /><br />";
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			include "../includes/scripts/footer.php";
			
		?>
	
	</body>
</html>