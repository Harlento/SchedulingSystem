<?php
/*  Developer:   Justin Alho
 *  File Name:   addgh.php
 *  Description: Allows coordinators to add new group home records into the database
 *  Date Start:  23/02/2020
 *  Date End:    TBD
 */?>
<html>

    <head>

        <title>Add New Group Home</title>
		<?php 
			//Starting a session and initializing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
			//include links to css, javascript, etc.
			include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//initialize variables
			$super = '';
			$name = '';
			$phone = '';
			$address = '';
			$city = '';
			
			$superr = '';
			$namerr = '';
		
			//connect to the database
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
		
			//if the form has been submitted
			if(isset($_POST['submit']))
			{	
				//set the error counter to 0
				$err = 0;
				
				//set variables to submitted values
				$super = $_POST['super'];
				$name = $_POST['name'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				
				//if required fields are blank, set the corresponding error message and increment error counter
				if($name == '')
				{
					$namerr = 'Please enter a name to identify the group home.';
					$err++;
				}
				
				if($super == '')
				{
					$superr = 'Please select a supervisor for the group home.';
					$err++;
				}

				//if there are no errors, add information into the database
				if($err == 0)
				{
					$sql = $conn->prepare("INSERT INTO 	group_home (STAFF_ID, GH_NAME, GH_PHONE, GH_ADDRESS, GH_CITY) VALUES ('$super', '$name', '$phone', '$address', '$city')");
					
					$sql->execute();

					$id = $conn->lastInsertId();
					$code = 'G' . $id;
					$desc = 'The department for ' . $name . '.';
					
					$depsql = $conn->prepare("INSERT INTO department (DEP_CODE, GH_ID, DEP_NAME, DEP_DESC) VALUES ('$code', '$id', '$name', '$desc')");
					$depsql->execute();
					
					//log whenever database is updated
					date_default_timezone_set("US/Mountain");
					//F j, Y, g:i a
					$dateString = date("r");
					file_put_contents("../logs/groupHomeAddLog.txt", "\n" . "Group home " . $name . " was added on: " . $dateString . " by " . $_SESSION['userName'] . ".", FILE_APPEND | LOCK_EX) ;
					
					//echo implode(":",$sql->errorInfo());
					
					//send the user back to this page with an empty form and a success message
					header('Location: addgh.php?s=1');
				}
			}
					
			//retrieve supervisor records from database
			$sql = $conn->prepare("SELECT STAFF_ID, STAFF_FNAME, STAFF_LNAME FROM staff WHERE TYPE_CODE = 'S'");
				
			$sql->execute();
			//echo implode(":",$sql->errorInfo());
			
			$row = $sql->fetchAll();
			
			//include navbar
			include "../includes/scripts/navBar.php";
			
			//if there is a successful database entry, display message
			if(isset($_REQUEST['s']))
				echo "Record added successfully.<br /><br />";	
			
			//display the form
			printf("

				<h1>Add New Group Home</h1>

				<form method='post' action='addgh.php'>

					<!--display selection of supervisors-->
					Supervisor:
						<select name='super'>
							<option value=''>Select a supervisor:</option>");
			foreach($row as $data)
				echo "<option value='{$data['STAFF_ID']}'>{$data['STAFF_FNAME']} {$data['STAFF_LNAME']}</option>";
			printf("
						</select>$superr<br /><br />\n
						
					Group Home Name:
						<input type='text' name='name' value='$name'>$namerr<br /><br />\n	
					
					Group Home Phone Number:
						<input type='tel' name='phone' pattern='[0-9]{3}-[0-9]{3}-[0-9]{4}' value='$phone'><br />
						Format: 000-000-0000<br /><br />\n
												
					Group Home Address:
						<input type='text' name='address' value='$address'><br /><br />\n
						
					Group Home City:
						<input type='text' name='city' value='$city'><br /><br />\n
					
					<input type='submit' name='submit' value='Submit'>\n

				</form>

				<!--cancel button that returns user to previous page-->
				<a href='/grouphome/' class='btn btn-danger'>Cancel</a>
			");
						
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
			//include footer
			include "../includes/scripts/footer.php";
        ?>

    </body>

</html>