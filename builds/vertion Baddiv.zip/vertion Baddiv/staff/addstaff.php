<?php
/*  Developer:   Justin Alho, Harley Lenton
 *  File Name:   addstaff.php
 *  Description: Allows coordinators to add new staff records into the database
 *  Date Start:  23/02/2020
 *  Date End:    TBD
 */?>
<?php
echo'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Add New Staff Member</title>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="css/table.css" rel="stylesheet" type="text/css">
				<script>
				//change whether or nor availability is displayed depending on staff type
				function showAvail(type) {
					if (window.XMLHttpRequest)
					{
						xmlhttp = new XMLHttpRequest();
					}
					xmlhttp.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							document.getElementById("availBox").innerHTML = this.responseText;
						}
					};
					xmlhttp.open("GET","addstaff.php?change="+type,true);
					xmlhttp.send();
				}
			</script>

</head>
<body>';
			#Starting a session and initilizing variables needed
	
			session_start();
			$userType = $_SESSION['userType'];
					include "../includes/scripts/headLinks2.0.php"; 
					include "../includes/scripts/navBar.php";
					include "../includes/functions/isSpecial.php";
					include "../includes/functions/isComplex.php";
					
echo'
<div class="row justify-content-center">

    
';


        
			//level of authorization required to access page
			$authLevel = "C";
			
			//to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			//to verify the user's type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			//connect to the database
			$username = 'Coordinator';
			$password = 'Password1';
			$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
			
			//initialize variables
			$type = '';
			$uname = '';
			$pass1 = '';
			$pass2 = '';
			$fname = '';
			$lname = '';
			$phone = '';
			$address = '';
			$city = '';
			$child = '';
			$pc = '';
			$drive = '';
			
			$sunAvail = '';
			$sunSt = '';
			$sunEnd = '';
			$monAvail = '';
			$monSt = '';
			$monEnd = '';
			$tueAvail = '';
			$tueSt = '';
			$tueEnd = '';
			$wedAvail = '';
			$wedSt = '';
			$wedEnd = '';
			$thuAvail = '';
			$thuSt = '';
			$thuEnd = '';
			$friAvail = '';
			$friSt = '';
			$friEnd = '';
			$satAvail = '';
			$satSt = '';
			$satEnd = '';
			$notes = '';
			
			$typerr = '';
			$unerr = '';
			$paserr = '';
			$fnerr = '';
			$lnerr = '';
		
			//if the form has been submitted
			if(isset($_POST['submit']))
			{	
				//set the error counter to 0
				$err = 0;
				
				//set variables to submitted values
				$type = $_POST['type'];
				$uname = $_POST['uname'];
				$pass1 = $_POST['pass1'];
				$pass2 = $_POST['pass2'];
				$fname = $_POST['fname'];
				$lname = $_POST['lname'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				if(isset($_POST['child']))
					$child = 1;
				else
					$child = 0;
				if(isset($_POST['pc']))
					$pc = 1;
				else
					$pc = 0;
				if(isset($_POST['drive']))
					$drive = 1;
				else
					$drive = 0;
				
				//if the staff is a worker or coordinator, save their availability
				if($_POST['type'] == 'W' || $_POST['type'] == 'S')
				{
					//start and end times are submitted separately, but stored in the database as one field
					$sunSt = $_POST['sunSt'];
					$sunEnd = $_POST['sunEnd'];
					$sunAvail = $sunSt . " - " . $sunEnd;
					$monSt = $_POST['monSt'];
					$monEnd = $_POST['monEnd'];
					$monAvail = $monSt . " - " . $monEnd;
					$tueSt = $_POST['tueSt'];
					$tueEnd = $_POST['tueEnd'];
					$tueAvail = $tueSt . " - " . $tueEnd;
					$wedSt = $_POST['wedSt'];
					$wedEnd = $_POST['wedEnd'];
					$wedAvail = $wedSt . " - " . $wedEnd;
					$thuSt = $_POST['thuSt'];
					$thuEnd = $_POST['thuEnd'];
					$thuAvail = $thuSt . " - " . $thuEnd;
					$friSt = $_POST['friSt'];
					$friEnd = $_POST['friEnd'];
					$friAvail = $friSt . " - " . $friEnd;
					$satSt = $_POST['satSt'];
					$satEnd = $_POST['satEnd'];
					$satAvail = $satSt . " - " . $satEnd;
				}
				$notes = $_POST['notes'];
				
				//if required fields are blank, set the corresponding error message and increment error counter
				if($type == '')
				{
					$typerr = 'Please specify a user type.';
					$err++;
				}
				if($uname == '')
				{
					$unerr = 'Please enter a username.';
					$err++;
				}
				if($pass1 == '')
				{
					$paserr = 'Please enter a password.';
					$err++;
				}
				else if($pass1 != $pass2)
				{
					$paserr = 'The passwords did not match.';
					$err++;
				}
				
				//if the password is not complex enough,
				//increment error counter and set different error message
				else if(!isComplex($pass2))
				{
					$paserr = "Password is not complex enough.";
					$err++;
				}
				if($fname == '')
				{
					$fnerr = 'Please enter a first name.';
					$err++;
				}
				if($lname == '')
				{
					$lnerr = 'Please enter a last name.';
					$err++;
				}
				
				//To determine whether the staff member's username is unique//////////////////////////////////
				
				$qry = $conn->prepare("SELECT * FROM STAFF WHERE USER_NAME = '$uname'");
				
				$qry->execute();
				
				$qryArray = $qry->fetchAll();
				
				if(sizeof($qryArray) > 0)
				{
					$err++;
					$unerr = 'That username is already in use.';
				}
				
				//////////////////////////////////////////////////////////////////////////////////////////////
				
				//if there are no errors, add information into the database
				if($err == 0)
				{
					//hash the password
					$pass = password_hash($pass, PASSWORD_BCRYPT);
					
					$sql = $conn->prepare("INSERT INTO STAFF (TYPE_CODE, USER_NAME, USER_PASS, STAFF_FNAME, STAFF_LNAME, STAFF_PHONE, STAFF_ADDRESS, STAFF_CITY, CAN_CHILD, CAN_PC, CAN_DRIVE, SUN_AVAIL, MON_AVAIL, TUE_AVAIL, WED_AVAIL, THU_AVAIL, FRI_AVAIL, SAT_AVAIL, STAFF_NOTES)
					VALUES ('$type', '$uname', '$pass', '$fname', '$lname', '$phone', '$address', '$city', '$child', '$pc', '$drive', '$sunAvail', '$monAvail', '$tueAvail', '$wedAvail', '$thuAvail', '$friAvail', '$satAvail', '$notes')");
					
					$sql->execute();
					
					//echo implode(":",$sql->errorInfo());
					
					//based on user type, set the typeName variable
					switch($type)
					{
						case "C":
							$typeName = "Coordinator";
						break;
						case "W":
							$typeName = "Worker";
						break;
						case "S":
							$typeName = "Supervisor";
						break;
						case "B";
							$typeName = "Bookkeeper";
						break;
						default:
							$typeName = "Unknown type";
						break;
						
					}
					
					//log whenever database is updated
					date_default_timezone_set("US/Mountain");
					//F j, Y, g:i a
					$dateString = date("r");
					file_put_contents("../logs/staffAddLog.txt", "\n" . $fname . " " . $lname . " was added as a " . $typeName . " with the User Name " . $uname .  " on: " . $dateString, FILE_APPEND | LOCK_EX);
					
					//send the user back to this page with an empty form and a success message
					header ("Location: addstaff.php?p=1");
				}
			}
			
			//retrieve user type records from database
			$sql = $conn->prepare("SELECT * FROM user_type");
				
			$sql->execute();
			
			$row = $sql->fetchAll();
			
			//if the AJAX call to show availability or not has been called
			if(isset($_REQUEST['change']))
			{
				//if the staff member is a worker or supervisor, display the worker-exclusive fields
				if($_REQUEST['change'] == 'W' || $_REQUEST['change'] == 'S')
				{
					printf("Availability: <br /><br />
							Sunday:
								Start:
									<input class='form-fan' type='time' name='sunSt' value='$sunSt'>
								End:
									<input class='form-fan' type='time' name='sunEnd' value='$sunEnd'><br /><br />
							Monday:
								Start:
									<input class='form-fan' type='time' name='monSt' value='$monSt'>
								End:
									<input class='form-fan' type='time' name='monEnd' value='$monEnd'><br /><br />

							Tuesday:
								Start:
									<input class='form-fan' type='time' name='tueSt' value='$tueSt'>
								End:
									<input class='form-fan' type='time' name='tueEnd' value='$tueEnd'><br /><br />

							 Wednesday:
								Start:
									<input class='form-fan' type='time' name='wedSt' value='$wedSt'>
								End:
									<input class='form-fan' type='time' name='wedEnd' value='$wedEnd'><br /><br />

							 Thursday:
								Start:
									<input class='form-fan' type='time' name='thuSt' value='$thuSt'>
								End:
									<input class='form-fan' type='time' name='thuEnd' value='$thuEnd'><br /><br />

							 Friday:
								Start:
									<input class='form-fan' type='time' name='friSt' value='$friSt'>
								End:
									<input class='form-fan' type='time' name='friEnd' value='$friEnd'><br /><br />

							 Saturday:
								Start:
									<input class='form-fan' type='time' name='satSt' value='$satSt'>
								End:
									<input class='form-fan' type='time' name='satEnd' value='$satEnd'><br /><br />

						Able to Drive:");
					if(isset($_POST['drive']))
						echo "<input class='form-fan' type='checkbox' name='drive' checked><br /><br />";
					else
						echo "<input class='form-fan' type='checkbox' name='drive'><br /><br />";
					
						echo "Can Provide Personal Care:";
					if(isset($_POST['pc']))
						echo "<input class='form-fan' type='checkbox' name='pc' checked><br /><br />";
					else
						echo "<input class='form-fan' type='checkbox' name='pc'><br /><br />";
					printf("
								Can work with Children:");
					if(isset($_POST['child']))
						echo "<input class='form-fan' type='checkbox' name='child' checked><br /><br />";
					else
						echo "<input class='form-fan' type='checkbox' name='child'><br /><br />";
				}
				
				//end the script here so nothing else is shown
				die();
			}
			
			//include navbar
			
			echo "<div class='container'>";
				
			//if there is a successful database entry, display message
			if(isset($_REQUEST['p']))
				echo "Staff member added successfully.<br /><br />";
			
			//display the form
			printf("
				
			
				<h1>Add New Staff Member</h1>

				<form class='form-con' method='post' action='addstaff.php'>

					First Name:
						<input class='form-fan' type='text' name='fname' value='$fname'>$fnerr
					Last Name:
						<input class='form-fan' type='text' name='lname' value='$lname'>$lnerr<br /><br />\n

					Full Address:
						<input class='form-fan' type='text' name='address' value='$address'>
					City:
						<input class='form-fan' type='text' name='city' value='$city'><br /><br />\n

					Primary Phone Number:
						<input class='form-fan' type='tel' name='phone' pattern='[0-9]{3}-[0-9]{3}-[0-9]{4}' value='$phone'><br />
						Format: 000-000-0000<br /><br />\n

					<!--display selection of user types-->
					User Type:
						<select class='fanc' name='type' onchange='showAvail(this.value)'>
							<option value=''>Select one:</option>
			");
			foreach($row as $data)
				echo "<option value='{$data['TYPE_CODE']}'>{$data['TYPE_NAME']}</option>";
			printf("
						</select>$typerr<br /><br />\n");
						
					if(isset($_REQUEST['message']))
						{
							echo "<p style='color: red;'>" . $_REQUEST['message'] . "</p>";
						}
			printf("
					User Name:
						<input class='form-fan' type='text' name='uname' value='$uname'>$unerr<br /><br />
									
						
					Password:<br /><br />
						Enter password: <input class='form-fan' type='password' name='pass1' value='$pass1'>$paserr<br /><br />
						Confirm password: <input class='form-fan' type='password' name='pass2' value=''><br /><br />
						Passwords need to be at least 8 characters long and include a number,<br />
						a lowercase letter, an uppercase letter, and a special character.<br /><br />

					<div id='availBox'>
					</div>");
			
			printf("	
					Notes:<br />
						<textarea input class='form-fan' name='notes' rows='3' cols='30'>$notes</textarea><br /><br />
						
					<input class='form-fan' type='submit' name='submit' value='Submit' class='btn btn-primary'>\n
					
					<a href='/staff/' class='btn btn-danger'>Cancel</a>

				</form>
				
				<!--cancel button that returns user to previous page-->
				
			</div>

			");
			
			//releasing database resources
			if(isset($conn) )
			{
				$conn = null;
			}
			
echo'
            

    
</form>
</div>';
	include "../includes/scripts/footer.php";
	echo'
</body>
</html>
    ';
	?>