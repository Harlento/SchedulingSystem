<?php

	print('
	
		<div class="footer">
			<p>Copyright Edenbridge Family Services Inc 2020</p>
			<p><a href="">About</a></p>
		</div>
	
	');

?>