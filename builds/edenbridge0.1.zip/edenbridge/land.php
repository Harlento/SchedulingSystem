<html>
    
    <head>

        <title>Landing Page</title>
		<?php include "./includes/scripts/headLinks.php"; ?>

    </head>
    
    <body>

        

        <?php

            session_start();

            //Verify creddentials

            //Include header

            //Include navbar
			include "./includes/scripts/navBar.php";
            //Potentially include mobile navbar

            include "./includes/scripts/logIn.php";

			//test value
			$_SESSION['userType'] = 'C';
			
            if(isset($_SESSION['userType']))
            {

                //Custom content based on user type

                $userType = $_SESSION['userType'];

                switch($userType)
                {

                    case "W":

                        printf("

                            <div>
                                <a href='/shifts/viewSched.php'>Check Schedule</a>
                                <a href='/deadEnd.php'>Submit Hours</a>
                            </div>

                        ");
						include "./includes/scripts/footer.php";


                        //Include footer

                        break;

                    case "B":

                        printf("

                            <a href='/deadEnd.php'>View Reports</a>
                            <a href=''></a>

                        ");
						include "./includes/scripts/footer.php";

                        //Include footer

                        break;

                    case "C":

                        printf('

							<h1></h1>
                            <a href="/staff/addstaff.php">Add Employee</a>
                            <a href="/staff/modstaff.php">Edit Employee Information</a>
                            <a href="/client/addclient.php">Add Client</a>
                            <a href="/client/modclient.php">Edit Client Information</a>
                            <a href="/grouphome/addgh.php">Add Group Home</a>
                            <a href="/grouphome/modgh.php">Edit Group Home</a>
							
                            <a href="/shifts/schedshift.php">Add Shift</a>
                            <a href="/shifts/modshift.php">Modify Shift</a>
							<a href="/deadEnd.php">Approve Hours</a>

                        ');
						include "./includes/scripts/footer.php";

                        //Include footer

                        break;

                    case "S":

                        printf("
                        
                            

                        ");
						include "./includes/scripts/footer.php";

                        break;

                    default:
						//test
						echo "Type code not valid";

                        //header("Location: index.php?message=invalidCreds");
						include "./includes/scripts/footer.php";

                        break;

                }

            }
            else
            {

                //This will be the address of the log in page this is only a placeholder value with a get variable passed through the redirect
                //the variable can be used to change the login page to say "Invalid credentials" or something like that.
				echo "Credentials not valid.";
				include "./includes/scripts/footer.php";
                //header("Location: index.php?message=invalidCreds");

            }

        ?>

    </body>

</html>