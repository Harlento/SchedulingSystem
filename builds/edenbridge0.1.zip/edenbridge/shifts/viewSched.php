<html>
    
    <head>
        <title>View Schedule</title>
		<?php session_start(); ?>
		<?php include "../includes/scripts/headLinks2.0.php"; ?>

    </head>
    
    <body>

        <?php
			
			//test variable!!!
			$_SESSION['staffId'] = "4";
			
			if(isset($_SESSION['staffId']))
			{
				$staffId = $_SESSION['staffId'];
			}
            //Verify user

            //Include header

            //Include navbar
            //Possibly a mobile specific navbar include as well

            //Calendar goes here
            //include "C:/www/edenbridge/calendarClass.php";

            //$calendar = new Calendar();
			
			include "../includes/scripts/navBar.php";
			
            //printing the calendar
            //print( $calendar->show() );

            //This will query the db for the required information
            $username = 'Coordinator';
            $password = 'Password1';

            $conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);

            $stm = $conn->prepare("SELECT shift_date, scheduled_start, scheduled_end
            FROM shift
            WHERE staff_id = ?
            AND status_code = ?
            ");
			
			//
			$staffId = $_SESSION['staffId'];
			$exeParams = array($staffId, "S");

            $stm->execute($exeParams);

            $dataArray = $stm->fetchAll(PDO::FETCH_ASSOC);
			$array = array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);

            //Date information
            $numODays = date('t');
            $year = date('Y');
            $month = date('m');

            //Test print values
            print($numODays);
            print($year);
            print($month);
            print_r($dataArray);
			print($staffId);

			include "../includes/scripts/footer.php";
			
        ?>
        <script>
			/**/
			
                var index;
                var array = <?php echo json_encode($dataArray); ?>;
                var numODays = <?php echo $numODays; ?>;

                var year = <?php echo $year; ?>;
                var month = <?php echo $month; ?>;
                //var day = <?php echo $day; ?>;
				
				//Test, this works on my computer.
				document.getElementById("li-2020-03-10").innerHTML = "What the heck!!!!!!!!!";

                if (month < 10)
                {
                    month = "0" + month;
                }
				
				var date = "li-" + year + "-" + month;

                for(index = 0; index < numODays; ++index)
                {
					
					let day = index;
                    //let row = <?php echo json_encode($dataArray[index]); ?>;
					
					//This should fetch each row in the query result and turn it into a js array
					for(i = 0; i < array.length; ++i)
					{
						<?php $row = $stm->fetch(PDO::FETCH_ASSOC); ?>
						let row = <?php echo json_encode($row); ?>;
						
						
						//test
						let x = document.getElementById(date + "-0" + "10").innerHTML;
						document.getElementById(date + "-" + "10").innerHTML = x + row;
						
						if (row['SHIFT_DATE'] == date)
						{
							   
							 if(index < 9)
							 {
								let x = document.getElementById(date + "-0" + day).innerHTML;
								document.getElementById(date + "-0" + day).innerHTML = x + row['START_TIME'];
							 }
							 else
							 {
								let x = document.getElementById(date + "-" + day).innerHTML;
								document.getElementById(date + "-" + day).innerHTML = x + row['START_TIME'];
							 }

						}
					}
					
				}
			
            
        </script>

    </body>

</html>