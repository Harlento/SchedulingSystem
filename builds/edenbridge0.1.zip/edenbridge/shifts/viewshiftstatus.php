<?php

	echo
	"<html>
	<head>
	";
	
	include "../includes/scripts/headLinks2.0.php";
	
	echo "
	</head>
	<body>";
	$username = 'Coordinator';
	$password = 'Password1';
	$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
			
	$sql = $conn->prepare("SELECT * FROM shift_status");
		
	$sql->execute();
	
	$row = $sql->fetchAll();
	
	include "../includes/scripts/navBar.php";
	
	echo
	"<table border='1'>
		<tr>
			<th>Status Code</th>
			<th>Status Name</th>
		</tr>
	";
	
	foreach ($row as $data)
	{
		echo "<tr>";
		echo "<td>{$data['STATUS_CODE']}</td>";
		echo "<td><a href='modshiftstatus.php?code={$data['STATUS_CODE']}&name={$data['STATUS_NAME']}'>{$data['STATUS_NAME']}</a></td>";
		echo "</tr>";
	}
		
	echo "</table><br />\n";
	
	include "../includes/scripts/footer.php";
		
	echo
	"</body>
	</html>";

?>