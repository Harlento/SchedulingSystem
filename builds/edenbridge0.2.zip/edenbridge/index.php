<html>

    <head>
        <title>Log in</title>
		<?php include "./includes/scripts/headLinks.php"; ?>
    </head>

    <body>

        <?php

            session_start();
			
			#test value!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			$userType = "";
			
			include "./includes/functions/isSpecial.php";
			include "./includes/functions/isComplex.php";

            //Include header

            include "./includes/scripts/navBar.php";
            //Potentially include mobile navbar

            printf("
                
                <form method='post' action='land.php'>
                    <input type='text' name='userName' value='' /><br /><br />
                    <input type='password' name='password' value='' /><br /><br />
                    <input type='submit' value='Login'>
                </form>

            ");

            include "./includes/scripts/footer.php";

        ?>

    </body>

</html>