<html>

    <head>

        <title>Modify Department</title>
		<?php 
			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
		?>
		<?php include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
			
			#to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			#test!!!!!!!!!!!!!!!!!!!!!!!1
			#print($authLevel);
			
			#to verify the users type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			
			$code = '';
			$name = '';
			$desc = '';
		
			if(isset($_POST['submit']))
			{	
				$code = $_POST['code'];
				$name = $_POST['name'];
				$desc = $_POST['desc'];
				
				$username = 'Coordinator';
				$password = 'Password1';
				$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);

				$sql = $conn->prepare("UPDATE DEPARTMENT SET DEP_NAME = '$name', DEP_DESC = '$desc' WHERE DEP_CODE = '$code'");
				
				$sql->execute();
				
				//echo implode(":",$sql->errorInfo());
				
				echo "record updated successfully.<br /><br />";
			}
			else
			{
				$code = $_REQUEST['code'];
				$username = 'Coordinator';
				$password = 'Password1';
				$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
						
				$sql = $conn->prepare("SELECT * FROM DEPARTMENT WHERE DEP_CODE = '$code'");
					
				$sql->execute();
				
				$row = $sql->fetch();
				
				include "../includes/scripts/navBar.php";
				
				printf("

					<h1>Modify Department</h1>

					<form method='post' action='moddep.php'>
							
						Department Code: $code<br /><br />\n
						<input type='hidden' name='code' value='$code'>
							
						Department Name:
							<input type='text' name='name' value='{$row['DEP_NAME']}'><br /><br />\n

						Department Description:
							<textarea name='desc'>{$row['DEP_DESC']}</textarea><br /><br />\n

						<input type='submit' name='submit' value='Update'>\n

					</form>

				");
				
				include "../includes/scripts/footer.php";
				
			}
        ?>

    </body>

</html>