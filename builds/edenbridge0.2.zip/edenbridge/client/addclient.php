<html>

    <head>

        <title>Add New Client</title>
		<?php 
			#Starting a session and initilizing variables needed
			session_start(); 
			$userType = $_SESSION['userType'];
		
		?>
		<?php include "../includes/scripts/headLinks2.0.php"; ?>

    </head>

    <body>

        <?php
		
			//level of authorization required to access page
			$authLevel = "C";
		
			#to verify the user 
			include "../includes/functions/verLogin.php";
			verLogin();
			
			#to verify the users type
			include "../includes/functions/valUserType.php";
			valUserType($authLevel);
			
			
			$gh = '';
			$fname = '';
			$lname = '';
			$phone = '';
			$address = '';
			$city = '';
			$hours = '';
			$km = '';
			$notes = '';
		
			if(isset($_POST['submit']))
			{	
				$gh = $_POST['gh'];
				$fname = $_POST['fname'];
				$lname = $_POST['lname'];
				$phone = $_POST['phone'];
				$address = $_POST['address'];
				$city = $_POST['city'];
				$hours = $_POST['hours'];
				$km = $_POST['km'];
				$notes = $_POST['notes'];
				
				$username = 'Coordinator';
				$password = 'Password1';
				$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);

				
				$sql = $conn->prepare("INSERT INTO CLIENT (GH_ID, CLIENT_FNAME, CLIENT_LNAME, CLIENT_PHONE, CLIENT_ADDRESS, CLIENT_CITY, CLIENT_MAX_HOURS, CLIENT_KM, CLIENT_NOTES)
				VALUES ('$gh', '$fname', '$lname', '$phone', '$address', '$city', '$hours', '$km', '$notes')");
				
				$sql->execute();
				
				//echo implode(":",$sql->errorInfo());
				
				echo "record added successfully.<br /><br />";
			}
			else
			{
				$username = 'Coordinator';
				$password = 'Password1';
				$conn = new PDO("mysql:host=localhost; dbname=edenbridgetest", $username, $password);
						
				$sql = $conn->prepare("SELECT * FROM group_home");
					
				$sql->execute();
				
				$row = $sql->fetchAll();
				
				include "../includes/scripts/navBar.php";
				
				printf("

					<h1>Add New Client</h1>

					<form method='post' action='addclient.php'>

					First Name:
                        <input type='text' name='fname' value=''>
                    Last Name:
                        <input type='text' name='lname' value=''><br /><br />\n
                    Full Address:
                        <input type='text' name='address' value=''>
                    City:
                        <input type='text' name='city' value=''><br /><br />\n
                    Phone Number:
                        <input type='text' name='phone' value=''><br /><br />\n
                    Group Home:
                        <select name='gh'>
                            <option value=''>Select a Group Home:</option>");
				foreach($row as $data)
					echo "<option value='{$data['GH_ID']}'>{$data['GH_NAME']}</option>";
				printf("
                        </select><br /><br />
					Hours Per Month:
                        <input type='text' name='hours' value=''><br /><br /><br />\n
					Distance (in kilometers):
                        <input type='text' name='km' value=''><br /><br /><br />\n
					Notes:
						<textarea name='notes'>
						</textarea><br /><br />\n

						<input type='submit' name='submit' value='Submit'>

					</form>

				");
				
				include "../includes/scripts/footer.php";
				
			}
        ?>

    </body>

</html>