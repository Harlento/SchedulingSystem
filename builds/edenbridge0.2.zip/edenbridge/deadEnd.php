<html>
    
    <head>

        <title></title>

    </head>    

    <body>

        <?php

            //Include header

            //Include navbar
            //Potentially include mobile navbar
            
            printf("<h1>This is still in development.</h1>");

            //Include footer

        ?>

    </body>

</html>