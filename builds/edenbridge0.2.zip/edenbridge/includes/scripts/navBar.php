<?php
	
	//test value
	//$userType = "C";
	//$userType = "";
	switch($userType)
	{
		case "C":
		
			print('
			
				<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-primary">
					<a class="navbar-brand" href="#">
						<img src="../includes/images/Picture1.png" width="60" height="30" class="d-inline-block align-top" alt="">
						Edenbridge Employee Portal
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav mr-auto">
							<li class="nav-item active">
								<a class="nav-link" href="/index.php">Home <span class="sr-only">(current)</span></a>
							</li>
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									User Management
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdown">
									<a class="dropdown-item" href="/staff/addstaff.php">Add Employee</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="/staff/modstaff.php">Edit Employee Information</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="/client/addclient.php">Add Client</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="/client/modclient.php">Edit Client Information</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="/grouphome/addgh.php">Add Group Home</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="/grouphome/modgh.php">Edit Group Home</a>
								</div>

							</li>
							<li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									Shift Management
								</a>
								<div class="dropdown-menu" aria-labelledby="navbarDropdown">
									<a class="dropdown-item" href="/shifts/schedshift.php">Add shift</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="/shifts/modshift.php">Modify Shift</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="/deadEnd.php">Approve Hours</a>
								</div>

							</li>
						</ul>
						<form class="form-inline my-2 my-lg-0" method="post" action="/includes/scripts/logOut.php">
							<h5>Logged In as: Coordinator     .</h5>
							<button type="submit" class="btn btn-danger">Logout</button>
						</form>
					</div>
				</nav>	
			');
		
		break;
		
		case "W":
		
			print('
			
				<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-primary">
					<a class="navbar-brand" href="#">
						<img src="../includes/images/Picture1.png" width="60" height="30" class="d-inline-block align-top" alt="">
						Edenbridge Employee Portal
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav mr-auto">
						
							<li class="nav-item active">
								<a class="nav-link" href="/index.php">Home <span class="sr-only">(current)</span></a>
							</li>
							
							<li class="nav-item dropdown">
								<a class="nav-link" href="/shifts/viewSched.php">Check Schedule</a>

							</li>
							
							<li class="nav-item dropdown">
								<a class="nav-link" href="/staff/submithours.php">Submit hours</a>

							</li>
						 
						</ul>
						<form class="form-inline my-2 my-lg-0" method="post" action="/includes/scripts/logOut.php">
							<h5>Logged In as: Worker     .</h5>
							<button type="submit" class="btn btn-danger">Logout</button>
						</form>
					</div>

				</nav>
			
			');
			
			break;
			
		case "B":
		
			print('
			
				<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-primary">
					<a class="navbar-brand" href="#">
						<img src="../includes/images/Picture1.png" width="60" height="30" class="d-inline-block align-top" alt="">
						Edenbridge Employee Portal
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav mr-auto">
							<li class="nav-item active">
								<a class="nav-link" href="/index.php">Home <span class="sr-only">(current)</span></a>
							</li>
							
							<li class="nav-item dropdown">
								<a class="nav-link" href="/deadEnd.php">View Reports</a>

							</li>
						</ul>
						<form class="form-inline my-2 my-lg-0" method="post" action="/includes/scripts/logOut.php">
							<h5>Logged In as: Bookkeeper     .</h5>
							<button type="submit" class="btn btn-danger">Logout</button>
						</form>
					</div>

				</nav>
			
			');
			
			break;
			
		case "S":
			
			print('
			
				<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-primary">
					<a class="navbar-brand" href="#">
						<img src="../includes/images/Picture1.png" width="60" height="30" class="d-inline-block align-top" alt="">
						Edenbridge Employee Portal
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav mr-auto">
							<li class="nav-item active">
								<a class="nav-link" href="/index.php">Home <span class="sr-only">(current)</span></a>
							</li>
							<li class="nav-item active">
								<a class="nav-link" href="/index.php">Modify Shift <span class="sr-only">(current)</span></a>
							</li>
						</ul>
						<form class="form-inline my-2 my-lg-0" method="post" action="/includes/scripts/logOut.php">
							<h5>Logged In as: Supervisor     .</h5>
							<button type="submit" class="btn btn-danger">Logout</button>
						</form>
					</div>

				</nav>
			
			');
			
			break;
			
		default:
		
			print('
			
				<nav class="navbar navbar-expand-lg sticky-top navbar-dark bg-primary">
					<a class="navbar-brand" href="#">
						<img src="../includes/images/Picture1.png" width="60" height="30" class="d-inline-block align-top" alt="">
						Edenbridge Employee Portal
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

				</nav>
			
			');
			
	}

?>