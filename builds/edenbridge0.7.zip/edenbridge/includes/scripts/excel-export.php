<?php



function exportInExcel($fileName, $headerRow, $data) {

ini_set('max_execution_time', 1600); //increase max_execution_time to 10 min if data set is very large

$fileContent = implode("\t ", $headerRow)."\n";

foreach($data as $result) {

$fileContent .=  implode("\t ", $result)."\n";

}

header('Content-type: application/ms-excel'); // you can set csv format
header('Content-Disposition: attachment; filename='.$fileName);

echo $fileContent;
exit;

}

function get_customers_lists(){
$db = mysqli_connect("localhost","Coordinator","Password1","edenbridgetest");
$qry = "SELECT SHIFT_ID, SHIFT_DATE, SCHEDULED_START, SCHEDULED_END, DEP_NAME,
						SHIFT.CLIENT_ID, SHIFT.STAFF_ID, STAFF_LNAME, STAFF_FNAME, CLIENT_LNAME, CLIENT_FNAME
						FROM SHIFT
						LEFT JOIN STAFF
						ON SHIFT.STAFF_ID = STAFF.STAFF_ID
						LEFT JOIN CLIENT
						ON SHIFT.CLIENT_ID = CLIENT.CLIENT_ID
						LEFT JOIN DEPARTMENT
						ON SHIFT.DEP_CODE = DEPARTMENT.DEP_CODE
						WHERE SHIFT_DATE > '2020-03-01'
						AND SHIFT_DATE < '2020-03-15'
						ORDER BY STAFF_LNAME, CLIENT_LNAME ASC, SHIFT_DATE ASC, SCHEDULED_START ASC
					";
$product_query=mysqli_query($db,$qry) or die('Mysql Err1:'. mysqli_error($db));

$rec_list = array();

if($product_query)
{
    while($fetch_products=mysqli_fetch_array($product_query))
	{
		$rec_list[] = $fetch_products;
	}

}

return $rec_list;

}

$fileName = "excel_".date("d-m-y:h:s").".xls";
// $fileName = "report_".date("d-m-y:h:s").".csv";

$fetch_list = get_customers_lists();

$res_data = array();
$headerRow = array('ID','Shift Date','start','end','dep name', 'client id','staffid','staf l name','staff f name','client lname', 'client fname');  
foreach($fetch_list as $fetch_detail){


$res_data['SHIFT_ID'] = $fetch_detail['SHIFT_ID'];
$res_data['SHIFT_DATE'] = $fetch_detail['SHIFT_DATE'];
$res_data['SCHEDULED_START'] = $fetch_detail['SCHEDULED_START'];
$res_data['SCHEDULED_END'] = $fetch_detail['SCHEDULED_END'];
$res_data['DEP_NAME'] = ucfirst($fetch_detail['DEP_NAME']);
$res_data['CLIENT_ID'] = ucfirst($fetch_detail['CLIENT_ID']);
$res_data['STAFF_ID'] = ucfirst($fetch_detail['STAFF_ID']);
$res_data['STAFF_LNAME'] = ucfirst($fetch_detail['STAFF_LNAME']);
$res_data['STAFF_FNAME'] = ucfirst($fetch_detail['STAFF_FNAME']);
$res_data['CLIENT_LNAME'] = ucfirst($fetch_detail['CLIENT_LNAME']);
$res_data['CLIENT_FNAME'] = ucfirst($fetch_detail['CLIENT_FNAME']);

$data[] = $res_data;

}

exportInExcel($fileName, $headerRow, $data);

?>