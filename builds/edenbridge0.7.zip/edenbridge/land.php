<?php
/*  Developer:   Harley Lenton, Justin Alho
 *  File Name:   land.php
 *  Description: Acts as a homepage for users with links to other pages
 *  Date Start:  03/03/2020
 *  Date End:    TBD
 */
 session_start(); ?>
<html>
    
    <head>

        <title>Landing Page</title>
		
		<?php
		//include links to css, javascript, etc.
		include "./includes/scripts/headLinks2.0.php"; ?>

    </head>
    
    <body>

        <?php
			
			//Setting the userType var
			$userType = $_SESSION['userType'];
			
			//Include navbar
			include "./includes/scripts/navBar.php";
			
			echo "<br />";
			
			//to verify the user 
			include "./includes/functions/verLogin.php";
			verLogin();
			
            if(isset($_SESSION['userType']))
            {

                //set userType variable to the user's type
                $userType = $_SESSION['userType'];

				//different home page based on user type
                switch($userType)
                {
					//for the workers, they only get the option of either checking their schedule or submitting their hours
                    case "W":
					
                        printf("

                            <div>
                                <a href='/shifts/viewSched.php' class='btn btn-primary'><h1>Check Schedule</h1></a>
                                <a href='/shifts/timesheet.php' class='btn btn-primary'><h1>Submit Timesheet</h1></a><br /><br />
                                <a href='/staff/changepass.php' class='btn btn-primary'><h4>Change Password</h4></a>
                            </div>

                        ");

                        if(isset($_REQUEST['p']))
							echo '<script>alert("Your password has been changed.")</script>';
						
						break;

					//currently, bookkeepers can only view reports.
					//they should be able to do everything a coordinator can as well
                    case "B":

                        printf("
						
                            <a href='/etc/reports.php' class='btn btn-primary'>View Reports</a>
                        
						");

                        break;

					//coordinators are able to access almost every page
                    case "C":
                          /// min-height: 80%; width: 50%;
                        print('
							<div style="float: left;min-height: 80%; width: 50%; padding: 10px;">
								<h1><a href="/shifts/">Shifts</a></h1>
								<a href="/shifts/schedshift.php" class="btn btn-primary">Schedule Shift</a><br />
								<a href="/shifts/schedrecshift.php" class="btn btn-primary">Schedule Recurring Shifts</a><br />
								<a href="/shifts/viewshift.php" class="btn btn-primary">Manage Shifts</a><br />
								<a href="/shifts/viewrecshift.php" class="btn btn-primary">Manage Recurring Shifts</a><br />
								<a href="/shifts/approvetime.php" class="btn btn-primary">Approve Hours</a><br /><br />
								
								<h1><a href="/staff/">Staff</a></h1>
								<a href="/staff/addstaff.php" class="btn btn-primary">Add New Staff Member</a><br />
								<a href="/staff/viewstaff.php" class="btn btn-primary">Manage Staff</a><br /><br />
								
								<h1><a href="/client/">Clients</a></h1>
								<a href="/client/addclient.php" class="btn btn-primary">Add Client</a><br />
								<a href="/client/viewclient.php" class="btn btn-primary">Manage Clients</a><br /><br />
							</div>
							
							<div style="float: left;min-height: 80%; width: 50%; padding: 10px;">
								<h1><a href="/grouphome/">Group Homes</a></h1>
								<a href="/grouphome/addgh.php" class="btn btn-primary">Add Group Home</a><br />
								<a href="/grouphome/viewgh.php" class="btn btn-primary">Manage Group Homes</a><br /><br />
								
								<h1><a href="/department/">Departments</a></h1>
								<a href="/department/adddep.php" class="btn btn-primary">Add Department</a><br />
								<a href="/department/viewdep.php" class="btn btn-primary">Manage Departments</a><br /><br />
							</div>

                        ');

                        break;

					//supervisors are able to change the workers for shifts in group homes that they supervise
                    case "S":

                        printf("
                        
                            <a href='/shifts/supermod.php' class='btn btn-primary'>Modify Shift</a>

                        ");

                        break;

					//if their user type does not match somehow, the user is redirected to the login page
                    default:
					
						header("Location: index.php");
						
                        break;
                }

                //Include footer
                include "./includes/scripts/footer.php";

            }
            else
            {
				//if the user is not logged in, they are redirected to the login page
                header("Location: index.php");

            }

        ?>

    </body>

</html>